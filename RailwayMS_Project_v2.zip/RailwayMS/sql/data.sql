-- ============================================================
--  Railway Management System -- Sample Data
-- ============================================================
USE railway_db;

-- Admin + sample users (passwords are BCrypt of 'password123')
INSERT INTO users (name, email, password, phone, role) VALUES
('Admin User',  'admin@railway.com',  '$2a$10$Yn7P.FBfRuDd9HpLQUWmNOPz9lJkb3Yw8Mb6a1K1bVwX8aP3YDrGi', '9000000001', 'admin'),
('Ravi Kumar',  'ravi@example.com',   '$2a$10$Yn7P.FBfRuDd9HpLQUWmNOPz9lJkb3Yw8Mb6a1K1bVwX8aP3YDrGi', '9876543210', 'user'),
('Priya Sharma','priya@example.com',  '$2a$10$Yn7P.FBfRuDd9HpLQUWmNOPz9lJkb3Yw8Mb6a1K1bVwX8aP3YDrGi', '9876543211', 'user'),
('Arun Nair',   'arun@example.com',   '$2a$10$Yn7P.FBfRuDd9HpLQUWmNOPz9lJkb3Yw8Mb6a1K1bVwX8aP3YDrGi', '9876543212', 'user');

-- Stations
INSERT INTO stations (station_name, station_code) VALUES
('Chennai Central',    'MAS'),
('New Delhi',          'NDLS'),
('Mumbai CST',         'CSTM'),
('Howrah Junction',    'HWH'),
('Bangalore City',     'SBC'),
('Hyderabad Deccan',   'HYB'),
('Ahmedabad Junction', 'ADI'),
('Pune Junction',      'PUNE'),
('Tirupati',           'TPTY'),
('Vijayawada Junction','BZA');

-- Trains
INSERT INTO trains (train_number, train_name, source, destination, departure_time, arrival_time, total_seats, available_seats, fare) VALUES
('12621', 'Tamil Nadu Express',  'Chennai Central', 'New Delhi',        '22:00:00', '07:30:00', 200, 182, 1240.00),
('12627', 'Karnataka Express',   'Bangalore City',  'New Delhi',        '19:45:00', '09:10:00', 200,  24, 1380.00),
('12839', 'Howrah Mail',         'Mumbai CST',      'Howrah Junction',  '21:10:00', '23:45:00', 200,   0,  980.00),
('16057', 'Saptagiri Express',   'Chennai Central', 'Tirupati',         '06:30:00', '09:50:00', 200, 210,  185.00),
('22691', 'Rajdhani Express',    'New Delhi',       'Bangalore City',   '20:00:00', '05:40:00', 200,   8, 2100.00),
('12707', 'Andhra Pradesh Exp',  'Hyderabad Deccan','New Delhi',        '06:30:00', '10:55:00', 200, 155,  950.00);

-- Sample passengers
INSERT INTO passengers (name, age, gender, phone) VALUES
('Ravi Kumar',   28, 'Male',   '9876543210'),
('Priya Sharma', 24, 'Female', '9876543211'),
('Arun Nair',    35, 'Male',   '9876543212');

-- Sample tickets
INSERT INTO tickets (pnr_number, user_id, train_id, booking_date, travel_date, status, fare) VALUES
('PNR841293', 2, 1, '2026-06-01', '2026-06-15', 'Confirmed', 1240.00),
('PNR840976', 2, 3, '2026-06-02', '2026-06-20', 'Confirmed',  680.00),
('PNR839104', 3, 2, '2026-05-20', '2026-06-02', 'Cancelled', 1820.00);

-- ticket_passengers
INSERT INTO ticket_passengers (ticket_id, passenger_id, seat_number, coach, ticket_class) VALUES
(1, 1, 23, 'S4', 'AC'),
(2, 1, 14, 'S2', 'Sleeper'),
(3, 2,  7, 'A1', 'AC');

-- Payments
INSERT INTO payments (ticket_id, amount, payment_status, payment_method, transaction_id) VALUES
(1, 1240.00, 'Success',  'UPI',        'UPI20260601841293'),
(2,  680.00, 'Success',  'Net Banking', 'NB20260602840976'),
(3, 1820.00, 'Refunded', 'Card',        'CD20260520839104');
