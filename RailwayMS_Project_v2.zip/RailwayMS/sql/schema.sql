-- ============================================================
--  Railway Management System -- Database Schema
--  MySQL 8.0+
-- ============================================================

CREATE DATABASE IF NOT EXISTS railway_db;
USE railway_db;

-- -------------------------------------------------------
--  users
-- -------------------------------------------------------
CREATE TABLE users (
    user_id   INT AUTO_INCREMENT PRIMARY KEY,
    name      VARCHAR(100)  NOT NULL,
    email     VARCHAR(100)  NOT NULL UNIQUE,
    password  VARCHAR(255)  NOT NULL,   -- store BCrypt hash in production
    phone     VARCHAR(15),
    role      ENUM('user','admin') DEFAULT 'user',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- -------------------------------------------------------
--  stations
-- -------------------------------------------------------
CREATE TABLE stations (
    station_id   INT AUTO_INCREMENT PRIMARY KEY,
    station_name VARCHAR(100) NOT NULL,
    station_code VARCHAR(10)  NOT NULL UNIQUE
);

-- -------------------------------------------------------
--  trains
-- -------------------------------------------------------
CREATE TABLE trains (
    train_id         INT AUTO_INCREMENT PRIMARY KEY,
    train_number     VARCHAR(10)    NOT NULL UNIQUE,
    train_name       VARCHAR(100)   NOT NULL,
    source           VARCHAR(100)   NOT NULL,
    destination      VARCHAR(100)   NOT NULL,
    departure_time   TIME           NOT NULL,
    arrival_time     TIME           NOT NULL,
    total_seats      INT            NOT NULL DEFAULT 200,
    available_seats  INT            NOT NULL DEFAULT 200,
    fare             DECIMAL(10,2)  NOT NULL
);

-- -------------------------------------------------------
--  routes  (intermediate stops)
-- -------------------------------------------------------
CREATE TABLE routes (
    route_id   INT AUTO_INCREMENT PRIMARY KEY,
    train_id   INT NOT NULL,
    station_id INT NOT NULL,
    stop_order INT NOT NULL,
    FOREIGN KEY (train_id)   REFERENCES trains(train_id)   ON DELETE CASCADE,
    FOREIGN KEY (station_id) REFERENCES stations(station_id) ON DELETE CASCADE
);

-- -------------------------------------------------------
--  passengers
-- -------------------------------------------------------
CREATE TABLE passengers (
    passenger_id INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(100) NOT NULL,
    age          INT          NOT NULL,
    gender       ENUM('Male','Female','Other') NOT NULL,
    phone        VARCHAR(15)
);

-- -------------------------------------------------------
--  tickets
-- -------------------------------------------------------
CREATE TABLE tickets (
    ticket_id    INT AUTO_INCREMENT PRIMARY KEY,
    pnr_number   VARCHAR(20)   NOT NULL UNIQUE,
    user_id      INT           NOT NULL,
    train_id     INT           NOT NULL,
    booking_date DATE          NOT NULL DEFAULT (CURDATE()),
    travel_date  DATE          NOT NULL,
    status       ENUM('Confirmed','Waiting','Cancelled') DEFAULT 'Confirmed',
    fare         DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (user_id)  REFERENCES users(user_id)  ON DELETE CASCADE,
    FOREIGN KEY (train_id) REFERENCES trains(train_id) ON DELETE CASCADE
);

-- -------------------------------------------------------
--  ticket_passengers  (many passengers per ticket)
-- -------------------------------------------------------
CREATE TABLE ticket_passengers (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id    INT         NOT NULL,
    passenger_id INT         NOT NULL,
    seat_number  INT,
    coach        VARCHAR(10),
    ticket_class ENUM('General','Sleeper','AC') DEFAULT 'Sleeper',
    FOREIGN KEY (ticket_id)    REFERENCES tickets(ticket_id)       ON DELETE CASCADE,
    FOREIGN KEY (passenger_id) REFERENCES passengers(passenger_id) ON DELETE CASCADE
);

-- -------------------------------------------------------
--  payments
-- -------------------------------------------------------
CREATE TABLE payments (
    payment_id     INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id      INT           NOT NULL,
    amount         DECIMAL(10,2) NOT NULL,
    payment_date   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    payment_status ENUM('Success','Failed','Refunded') DEFAULT 'Success',
    payment_method VARCHAR(50),
    transaction_id VARCHAR(100),
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id) ON DELETE CASCADE
);
