package com.railway.model;

import java.math.BigDecimal;
import java.sql.Timestamp;

/** Payment – JavaBean matching the 'payments' table. */
public class Payment {

    private int        paymentId;
    private int        ticketId;
    private BigDecimal amount;
    private Timestamp  paymentDate;
    private String     paymentStatus;   // Success / Failed / Refunded
    private String     paymentMethod;   // UPI / Card / Net Banking
    private String     transactionId;

    public Payment() {}

    public int        getPaymentId()                    { return paymentId; }
    public void       setPaymentId(int v)               { this.paymentId = v; }

    public int        getTicketId()                     { return ticketId; }
    public void       setTicketId(int v)                { this.ticketId = v; }

    public BigDecimal getAmount()                       { return amount; }
    public void       setAmount(BigDecimal v)           { this.amount = v; }

    public Timestamp  getPaymentDate()                  { return paymentDate; }
    public void       setPaymentDate(Timestamp v)       { this.paymentDate = v; }

    public String     getPaymentStatus()                { return paymentStatus; }
    public void       setPaymentStatus(String v)        { this.paymentStatus = v; }

    public String     getPaymentMethod()                { return paymentMethod; }
    public void       setPaymentMethod(String v)        { this.paymentMethod = v; }

    public String     getTransactionId()                { return transactionId; }
    public void       setTransactionId(String v)        { this.transactionId = v; }
}
