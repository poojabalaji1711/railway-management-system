package com.railway.model;

/** Passenger – JavaBean matching the 'passengers' table. */
public class Passenger {

    private int    passengerId;
    private String name;
    private int    age;
    private String gender;   // Male / Female / Other
    private String phone;

    public Passenger() {}

    public Passenger(String name, int age, String gender, String phone) {
        this.name   = name;
        this.age    = age;
        this.gender = gender;
        this.phone  = phone;
    }

    public int    getPassengerId()              { return passengerId; }
    public void   setPassengerId(int v)         { this.passengerId = v; }

    public String getName()                     { return name; }
    public void   setName(String v)             { this.name = v; }

    public int    getAge()                      { return age; }
    public void   setAge(int v)                 { this.age = v; }

    public String getGender()                   { return gender; }
    public void   setGender(String v)           { this.gender = v; }

    public String getPhone()                    { return phone; }
    public void   setPhone(String v)            { this.phone = v; }
}
