package com.railway.model;

/** Station – JavaBean matching the 'stations' table. */
public class Station {

    private int    stationId;
    private String stationName;
    private String stationCode;

    public Station() {}

    public Station(String stationName, String stationCode) {
        this.stationName = stationName;
        this.stationCode = stationCode;
    }

    public int    getStationId()                { return stationId; }
    public void   setStationId(int v)           { this.stationId = v; }

    public String getStationName()              { return stationName; }
    public void   setStationName(String v)      { this.stationName = v; }

    public String getStationCode()              { return stationCode; }
    public void   setStationCode(String v)      { this.stationCode = v; }
}
