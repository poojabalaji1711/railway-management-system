package com.railway.model;

import java.sql.Timestamp;

/** User – JavaBean matching the 'users' table. */
public class User {

    private int       userId;
    private String    name;
    private String    email;
    private String    password;   // BCrypt hash
    private String    phone;
    private String    role;       // "user" or "admin"
    private Timestamp createdAt;

    public User() {}

    public User(String name, String email, String password, String phone, String role) {
        this.name     = name;
        this.email    = email;
        this.password = password;
        this.phone    = phone;
        this.role     = role;
    }

    // Getters & Setters
    public int       getUserId()            { return userId; }
    public void      setUserId(int v)       { this.userId = v; }

    public String    getName()              { return name; }
    public void      setName(String v)      { this.name = v; }

    public String    getEmail()             { return email; }
    public void      setEmail(String v)     { this.email = v; }

    public String    getPassword()          { return password; }
    public void      setPassword(String v)  { this.password = v; }

    public String    getPhone()             { return phone; }
    public void      setPhone(String v)     { this.phone = v; }

    public String    getRole()              { return role; }
    public void      setRole(String v)      { this.role = v; }

    public Timestamp getCreatedAt()             { return createdAt; }
    public void      setCreatedAt(Timestamp v)  { this.createdAt = v; }
}
