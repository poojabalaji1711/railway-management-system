package com.railway.model;

import java.math.BigDecimal;
import java.sql.Time;

/**
 * Train – JavaBean matching the 'trains' table.
 */
public class Train {

    private int       trainId;
    private String    trainNumber;
    private String    trainName;
    private String    source;
    private String    destination;
    private Time      departureTime;
    private Time      arrivalTime;
    private int       totalSeats;
    private int       availableSeats;
    private BigDecimal fare;

    // ── Constructors ──────────────────────────────────────────────────────
    public Train() {}

    public Train(int trainId, String trainNumber, String trainName,
                 String source, String destination,
                 Time departureTime, Time arrivalTime,
                 int totalSeats, int availableSeats, BigDecimal fare) {
        this.trainId        = trainId;
        this.trainNumber    = trainNumber;
        this.trainName      = trainName;
        this.source         = source;
        this.destination    = destination;
        this.departureTime  = departureTime;
        this.arrivalTime    = arrivalTime;
        this.totalSeats     = totalSeats;
        this.availableSeats = availableSeats;
        this.fare           = fare;
    }

    // ── Getters & Setters ─────────────────────────────────────────────────
    public int       getTrainId()         { return trainId; }
    public void      setTrainId(int v)    { this.trainId = v; }

    public String    getTrainNumber()            { return trainNumber; }
    public void      setTrainNumber(String v)    { this.trainNumber = v; }

    public String    getTrainName()              { return trainName; }
    public void      setTrainName(String v)      { this.trainName = v; }

    public String    getSource()                 { return source; }
    public void      setSource(String v)         { this.source = v; }

    public String    getDestination()            { return destination; }
    public void      setDestination(String v)    { this.destination = v; }

    public Time      getDepartureTime()          { return departureTime; }
    public void      setDepartureTime(Time v)    { this.departureTime = v; }

    public Time      getArrivalTime()            { return arrivalTime; }
    public void      setArrivalTime(Time v)      { this.arrivalTime = v; }

    public int       getTotalSeats()             { return totalSeats; }
    public void      setTotalSeats(int v)        { this.totalSeats = v; }

    public int       getAvailableSeats()         { return availableSeats; }
    public void      setAvailableSeats(int v)    { this.availableSeats = v; }

    public BigDecimal getFare()                  { return fare; }
    public void       setFare(BigDecimal v)      { this.fare = v; }

    @Override
    public String toString() {
        return "Train{" + trainNumber + " | " + trainName + " | " + source + " → " + destination + "}";
    }
}
