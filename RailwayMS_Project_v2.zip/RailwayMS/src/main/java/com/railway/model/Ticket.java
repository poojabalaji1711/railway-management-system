package com.railway.model;

import java.math.BigDecimal;
import java.sql.Date;

/** Ticket – JavaBean matching the 'tickets' table. */
public class Ticket {

    private int        ticketId;
    private String     pnrNumber;
    private int        userId;
    private int        trainId;
    private Date       bookingDate;
    private Date       travelDate;
    private String     status;     // Confirmed / Waiting / Cancelled
    private BigDecimal fare;

    // Joined fields (not in table – populated by DAO query)
    private String trainName;
    private String trainNumber;
    private String source;
    private String destination;

    public Ticket() {}

    // Getters & Setters
    public int        getTicketId()               { return ticketId; }
    public void       setTicketId(int v)          { this.ticketId = v; }

    public String     getPnrNumber()              { return pnrNumber; }
    public void       setPnrNumber(String v)      { this.pnrNumber = v; }

    public int        getUserId()                 { return userId; }
    public void       setUserId(int v)            { this.userId = v; }

    public int        getTrainId()                { return trainId; }
    public void       setTrainId(int v)           { this.trainId = v; }

    public Date       getBookingDate()            { return bookingDate; }
    public void       setBookingDate(Date v)      { this.bookingDate = v; }

    public Date       getTravelDate()             { return travelDate; }
    public void       setTravelDate(Date v)       { this.travelDate = v; }

    public String     getStatus()                 { return status; }
    public void       setStatus(String v)         { this.status = v; }

    public BigDecimal getFare()                   { return fare; }
    public void       setFare(BigDecimal v)       { this.fare = v; }

    public String     getTrainName()              { return trainName; }
    public void       setTrainName(String v)      { this.trainName = v; }

    public String     getTrainNumber()            { return trainNumber; }
    public void       setTrainNumber(String v)    { this.trainNumber = v; }

    public String     getSource()                 { return source; }
    public void       setSource(String v)         { this.source = v; }

    public String     getDestination()            { return destination; }
    public void       setDestination(String v)    { this.destination = v; }
}
