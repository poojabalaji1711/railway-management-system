package com.railway.dao;

import com.railway.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * ReportDAO – aggregated queries for the admin reports page.
 * Each method returns a List of Maps so the JSP can iterate without
 * needing extra model classes.
 */
public class ReportDAO {

    // ── Daily bookings (last 30 days) ─────────────────────────────────────
    public List<Map<String, Object>> getDailyBookings() throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<>();
        String sql =
            "SELECT DATE(booking_date) AS day, " +
            "       COUNT(*)           AS total_bookings, " +
            "       SUM(fare)          AS revenue " +
            "FROM tickets " +
            "WHERE status = 'Confirmed' " +
            "  AND booking_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) " +
            "GROUP BY DATE(booking_date) " +
            "ORDER BY day DESC";

        try (Connection con = DBConnection.getConnection();
             Statement st   = con.createStatement();
             ResultSet rs   = st.executeQuery(sql)) {

            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("day",            rs.getDate("day").toString());
                row.put("totalBookings",  rs.getInt("total_bookings"));
                row.put("revenue",        rs.getBigDecimal("revenue"));
                rows.add(row);
            }
        }
        return rows;
    }

    // ── Revenue by train ──────────────────────────────────────────────────
    public List<Map<String, Object>> getRevenueByTrain() throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<>();
        String sql =
            "SELECT t.train_name, t.train_number, " +
            "       COUNT(tk.ticket_id) AS bookings, " +
            "       SUM(tk.fare)        AS total_revenue " +
            "FROM trains t " +
            "JOIN tickets tk ON t.train_id = tk.train_id " +
            "WHERE tk.status = 'Confirmed' " +
            "GROUP BY t.train_id " +
            "ORDER BY total_revenue DESC";

        try (Connection con = DBConnection.getConnection();
             Statement st   = con.createStatement();
             ResultSet rs   = st.executeQuery(sql)) {

            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("trainName",    rs.getString("train_name"));
                row.put("trainNumber",  rs.getString("train_number"));
                row.put("bookings",     rs.getInt("bookings"));
                row.put("revenue",      rs.getBigDecimal("total_revenue"));
                rows.add(row);
            }
        }
        return rows;
    }

    // ── Cancellation report ───────────────────────────────────────────────
    public List<Map<String, Object>> getCancellationReport() throws SQLException {
        List<Map<String, Object>> rows = new ArrayList<>();
        String sql =
            "SELECT t.pnr_number, u.name AS user_name, " +
            "       tr.train_name, t.travel_date, t.fare, " +
            "       p.payment_status " +
            "FROM tickets t " +
            "JOIN users    u  ON t.user_id  = u.user_id " +
            "JOIN trains   tr ON t.train_id = tr.train_id " +
            "LEFT JOIN payments p ON t.ticket_id = p.ticket_id " +
            "WHERE t.status = 'Cancelled' " +
            "ORDER BY t.booking_date DESC";

        try (Connection con = DBConnection.getConnection();
             Statement st   = con.createStatement();
             ResultSet rs   = st.executeQuery(sql)) {

            while (rs.next()) {
                Map<String, Object> row = new LinkedHashMap<>();
                row.put("pnr",           rs.getString("pnr_number"));
                row.put("userName",      rs.getString("user_name"));
                row.put("trainName",     rs.getString("train_name"));
                row.put("travelDate",    rs.getDate("travel_date").toString());
                row.put("fare",          rs.getBigDecimal("fare"));
                row.put("refundStatus",  rs.getString("payment_status"));
                rows.add(row);
            }
        }
        return rows;
    }

    // ── Summary totals (for dashboard cards) ─────────────────────────────
    public Map<String, Object> getSummaryStats() throws SQLException {
        Map<String, Object> stats = new LinkedHashMap<>();
        String sql =
            "SELECT " +
            "  (SELECT COUNT(*) FROM tickets WHERE status='Confirmed')   AS total_bookings, " +
            "  (SELECT COALESCE(SUM(fare),0) FROM tickets WHERE status='Confirmed') AS total_revenue, " +
            "  (SELECT COUNT(*) FROM tickets WHERE status='Cancelled')   AS cancellations, " +
            "  (SELECT COUNT(*) FROM users WHERE role='user')            AS total_users, " +
            "  (SELECT COUNT(*) FROM trains)                             AS total_trains";

        try (Connection con = DBConnection.getConnection();
             Statement st   = con.createStatement();
             ResultSet rs   = st.executeQuery(sql)) {

            if (rs.next()) {
                stats.put("totalBookings",  rs.getInt("total_bookings"));
                stats.put("totalRevenue",   rs.getBigDecimal("total_revenue"));
                stats.put("cancellations",  rs.getInt("cancellations"));
                stats.put("totalUsers",     rs.getInt("total_users"));
                stats.put("totalTrains",    rs.getInt("total_trains"));
            }
        }
        return stats;
    }
}
