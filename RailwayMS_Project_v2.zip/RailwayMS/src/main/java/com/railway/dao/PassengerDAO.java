package com.railway.dao;

import com.railway.model.Passenger;
import com.railway.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * PassengerDAO – CRUD for the 'passengers' table.
 * Also handles inserting into 'ticket_passengers' join table.
 */
public class PassengerDAO {

    // ── Insert passenger and return generated ID ──────────────────────────
    public int addPassenger(Passenger p) throws SQLException {
        String sql = "INSERT INTO passengers (name, age, gender, phone) VALUES (?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, p.getName());
            ps.setInt(2,    p.getAge());
            ps.setString(3, p.getGender());
            ps.setString(4, p.getPhone());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        }
        return -1;
    }

    // ── Link passenger to a ticket ────────────────────────────────────────
    public void addTicketPassenger(int ticketId, int passengerId,
                                   int seatNumber, String coach,
                                   String ticketClass, Connection con) throws SQLException {
        String sql = "INSERT INTO ticket_passengers (ticket_id, passenger_id, seat_number, coach, ticket_class) "
                   + "VALUES (?,?,?,?,?)";

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1,    ticketId);
            ps.setInt(2,    passengerId);
            ps.setInt(3,    seatNumber);
            ps.setString(4, coach);
            ps.setString(5, ticketClass);
            ps.executeUpdate();
        }
    }

    // ── Get all passengers for a ticket ──────────────────────────────────
    public List<Passenger> getPassengersByTicket(int ticketId) throws SQLException {
        List<Passenger> list = new ArrayList<>();
        String sql = "SELECT p.*, tp.seat_number, tp.coach, tp.ticket_class "
                   + "FROM passengers p "
                   + "JOIN ticket_passengers tp ON p.passenger_id = tp.passenger_id "
                   + "WHERE tp.ticket_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, ticketId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Passenger p = new Passenger();
                    p.setPassengerId(rs.getInt("passenger_id"));
                    p.setName(rs.getString("name"));
                    p.setAge(rs.getInt("age"));
                    p.setGender(rs.getString("gender"));
                    p.setPhone(rs.getString("phone"));
                    list.add(p);
                }
            }
        }
        return list;
    }

    // ── Get all passengers (admin view) ───────────────────────────────────
    public List<Passenger> getAllPassengers() throws SQLException {
        List<Passenger> list = new ArrayList<>();
        String sql = "SELECT * FROM passengers ORDER BY name";

        try (Connection con = DBConnection.getConnection();
             Statement st   = con.createStatement();
             ResultSet rs   = st.executeQuery(sql)) {

            while (rs.next()) {
                Passenger p = new Passenger();
                p.setPassengerId(rs.getInt("passenger_id"));
                p.setName(rs.getString("name"));
                p.setAge(rs.getInt("age"));
                p.setGender(rs.getString("gender"));
                p.setPhone(rs.getString("phone"));
                list.add(p);
            }
        }
        return list;
    }

    // ── Update passenger ──────────────────────────────────────────────────
    public boolean updatePassenger(Passenger p) throws SQLException {
        String sql = "UPDATE passengers SET name=?, age=?, gender=?, phone=? WHERE passenger_id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getName());
            ps.setInt(2,    p.getAge());
            ps.setString(3, p.getGender());
            ps.setString(4, p.getPhone());
            ps.setInt(5,    p.getPassengerId());
            return ps.executeUpdate() > 0;
        }
    }
}
