package com.railway.dao;

import com.railway.model.Train;
import com.railway.util.DBConnection;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * TrainDAO – all CRUD operations on the 'trains' table.
 */
public class TrainDAO {

    // ── Search ──────────────────────────────────────────────────────────
    /**
     * Find trains by source and destination (case-insensitive).
     */
    public List<Train> searchTrains(String source, String destination) throws SQLException {
        List<Train> list = new ArrayList<>();
        String sql = "SELECT * FROM trains WHERE LOWER(source)=LOWER(?) AND LOWER(destination)=LOWER(?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, source);
            ps.setString(2, destination);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        }
        return list;
    }

    /** Find a single train by its train number (e.g. "12621"). */
    public Train getTrainByNumber(String trainNumber) throws SQLException {
        String sql = "SELECT * FROM trains WHERE train_number = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, trainNumber);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    /** Return every train (used in admin view). */
    public List<Train> getAllTrains() throws SQLException {
        List<Train> list = new ArrayList<>();
        String sql = "SELECT * FROM trains ORDER BY train_number";

        try (Connection con = DBConnection.getConnection();
             Statement  st  = con.createStatement();
             ResultSet  rs  = st.executeQuery(sql)) {

            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    // ── Create ──────────────────────────────────────────────────────────
    /**
     * Insert a new train and return the generated train_id.
     */
    public int addTrain(Train t) throws SQLException {
        String sql = "INSERT INTO trains (train_number, train_name, source, destination, "
                   + "departure_time, arrival_time, total_seats, available_seats, fare) "
                   + "VALUES (?,?,?,?,?,?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, t.getTrainNumber());
            ps.setString(2, t.getTrainName());
            ps.setString(3, t.getSource());
            ps.setString(4, t.getDestination());
            ps.setTime(5,   t.getDepartureTime());
            ps.setTime(6,   t.getArrivalTime());
            ps.setInt(7,    t.getTotalSeats());
            ps.setInt(8,    t.getTotalSeats());   // initially all seats available
            ps.setBigDecimal(9, t.getFare());

            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        }
        return -1;
    }

    // ── Update ──────────────────────────────────────────────────────────
    public boolean updateTrain(Train t) throws SQLException {
        String sql = "UPDATE trains SET train_name=?, source=?, destination=?, "
                   + "departure_time=?, arrival_time=?, total_seats=?, fare=? "
                   + "WHERE train_id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, t.getTrainName());
            ps.setString(2, t.getSource());
            ps.setString(3, t.getDestination());
            ps.setTime(4,   t.getDepartureTime());
            ps.setTime(5,   t.getArrivalTime());
            ps.setInt(6,    t.getTotalSeats());
            ps.setBigDecimal(7, t.getFare());
            ps.setInt(8,    t.getTrainId());

            return ps.executeUpdate() > 0;
        }
    }

    // ── Delete ──────────────────────────────────────────────────────────
    public boolean deleteTrain(int trainId) throws SQLException {
        String sql = "DELETE FROM trains WHERE train_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, trainId);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Seat availability ────────────────────────────────────────────────
    /** Decrement available_seats by 1 after a booking. */
    public void decrementSeat(int trainId, Connection con) throws SQLException {
        String sql = "UPDATE trains SET available_seats = available_seats - 1 WHERE train_id = ? AND available_seats > 0";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, trainId);
            ps.executeUpdate();
        }
    }

    /** Increment available_seats by 1 on cancellation. */
    public void incrementSeat(int trainId, Connection con) throws SQLException {
        String sql = "UPDATE trains SET available_seats = available_seats + 1 WHERE train_id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, trainId);
            ps.executeUpdate();
        }
    }

    // ── Helper ──────────────────────────────────────────────────────────
    private Train mapRow(ResultSet rs) throws SQLException {
        Train t = new Train();
        t.setTrainId(rs.getInt("train_id"));
        t.setTrainNumber(rs.getString("train_number"));
        t.setTrainName(rs.getString("train_name"));
        t.setSource(rs.getString("source"));
        t.setDestination(rs.getString("destination"));
        t.setDepartureTime(rs.getTime("departure_time"));
        t.setArrivalTime(rs.getTime("arrival_time"));
        t.setTotalSeats(rs.getInt("total_seats"));
        t.setAvailableSeats(rs.getInt("available_seats"));
        t.setFare(rs.getBigDecimal("fare"));
        return t;
    }
}
