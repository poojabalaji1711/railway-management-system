package com.railway.dao;

import com.railway.model.Station;
import com.railway.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** StationDAO – CRUD for the 'stations' table. */
public class StationDAO {

    public List<Station> getAllStations() throws SQLException {
        List<Station> list = new ArrayList<>();
        String sql = "SELECT * FROM stations ORDER BY station_name";

        try (Connection con = DBConnection.getConnection();
             Statement st   = con.createStatement();
             ResultSet rs   = st.executeQuery(sql)) {

            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public int addStation(Station s) throws SQLException {
        String sql = "INSERT INTO stations (station_name, station_code) VALUES (?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, s.getStationName());
            ps.setString(2, s.getStationCode().toUpperCase());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        }
        return -1;
    }

    public boolean updateStation(Station s) throws SQLException {
        String sql = "UPDATE stations SET station_name=?, station_code=? WHERE station_id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, s.getStationName());
            ps.setString(2, s.getStationCode().toUpperCase());
            ps.setInt(3,    s.getStationId());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean deleteStation(int stationId) throws SQLException {
        String sql = "DELETE FROM stations WHERE station_id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, stationId);
            return ps.executeUpdate() > 0;
        }
    }

    private Station mapRow(ResultSet rs) throws SQLException {
        Station s = new Station();
        s.setStationId(rs.getInt("station_id"));
        s.setStationName(rs.getString("station_name"));
        s.setStationCode(rs.getString("station_code"));
        return s;
    }
}
