package com.railway.dao;

import com.railway.model.Ticket;
import com.railway.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * TicketDAO – book, cancel, and retrieve tickets.
 * Booking uses a TRANSACTION to keep tickets and available_seats in sync.
 */
public class TicketDAO {

    private final TrainDAO trainDAO = new TrainDAO();

    // ── Book ─────────────────────────────────────────────────────────────
    /**
     * Books a ticket inside a single ACID transaction:
     *  1. Insert ticket row
     *  2. Decrement available_seats
     *  3. Insert payment row
     *
     * @return generated ticket_id, or -1 on failure
     */
    public int bookTicket(Ticket ticket, String paymentMethod) throws SQLException {
        String insertTicket  = "INSERT INTO tickets (pnr_number, user_id, train_id, travel_date, status, fare) "
                             + "VALUES (?,?,?,?,?,?)";
        String insertPayment = "INSERT INTO payments (ticket_id, amount, payment_status, payment_method) "
                             + "VALUES (?,?,'Success',?)";

        Connection con = null;
        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false); // BEGIN TRANSACTION

            // 1. Insert ticket
            int ticketId;
            try (PreparedStatement ps = con.prepareStatement(insertTicket, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, ticket.getPnrNumber());
                ps.setInt(2,    ticket.getUserId());
                ps.setInt(3,    ticket.getTrainId());
                ps.setDate(4,   ticket.getTravelDate());
                ps.setString(5, "Confirmed");
                ps.setBigDecimal(6, ticket.getFare());
                ps.executeUpdate();

                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (!keys.next()) throw new SQLException("Ticket insert failed.");
                    ticketId = keys.getInt(1);
                }
            }

            // 2. Decrement seat count (also validates availability)
            trainDAO.decrementSeat(ticket.getTrainId(), con);

            // 3. Insert payment record
            try (PreparedStatement ps = con.prepareStatement(insertPayment)) {
                ps.setInt(1,    ticketId);
                ps.setBigDecimal(2, ticket.getFare());
                ps.setString(3, paymentMethod);
                ps.executeUpdate();
            }

            con.commit(); // COMMIT TRANSACTION
            return ticketId;

        } catch (SQLException ex) {
            if (con != null) con.rollback(); // ROLLBACK on error
            throw ex;
        } finally {
            if (con != null) { con.setAutoCommit(true); con.close(); }
        }
    }

    // ── Cancel ────────────────────────────────────────────────────────────
    public boolean cancelTicket(int ticketId) throws SQLException {
        String updateTicket  = "UPDATE tickets  SET status='Cancelled' WHERE ticket_id=?";
        String updatePayment = "UPDATE payments SET payment_status='Refunded' WHERE ticket_id=?";

        // Find which train to restore seat
        int trainId = getTrainIdByTicket(ticketId);

        Connection con = null;
        try {
            con = DBConnection.getConnection();
            con.setAutoCommit(false);

            try (PreparedStatement ps = con.prepareStatement(updateTicket)) {
                ps.setInt(1, ticketId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = con.prepareStatement(updatePayment)) {
                ps.setInt(1, ticketId);
                ps.executeUpdate();
            }
            trainDAO.incrementSeat(trainId, con);

            con.commit();
            return true;
        } catch (SQLException ex) {
            if (con != null) con.rollback();
            throw ex;
        } finally {
            if (con != null) { con.setAutoCommit(true); con.close(); }
        }
    }

    // ── Retrieve ──────────────────────────────────────────────────────────
    /** All tickets for a specific user (with joined train info). */
    public List<Ticket> getTicketsByUser(int userId) throws SQLException {
        List<Ticket> list = new ArrayList<>();
        String sql = "SELECT t.*, tr.train_name, tr.train_number, tr.source, tr.destination "
                   + "FROM tickets t JOIN trains tr ON t.train_id = tr.train_id "
                   + "WHERE t.user_id = ? ORDER BY t.booking_date DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    /** Lookup by PNR number. */
    public Ticket getTicketByPNR(String pnr) throws SQLException {
        String sql = "SELECT t.*, tr.train_name, tr.train_number, tr.source, tr.destination "
                   + "FROM tickets t JOIN trains tr ON t.train_id = tr.train_id "
                   + "WHERE t.pnr_number = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, pnr);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    // ── PNR generator ─────────────────────────────────────────────────────
    /** Generates a unique PNR string. */
    public static String generatePNR() {
        return "PNR" + System.currentTimeMillis() % 1_000_000;
    }

    // ── Helper ────────────────────────────────────────────────────────────
    private int getTrainIdByTicket(int ticketId) throws SQLException {
        String sql = "SELECT train_id FROM tickets WHERE ticket_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, ticketId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt("train_id");
            }
        }
        throw new SQLException("Ticket not found: " + ticketId);
    }

    private Ticket mapRow(ResultSet rs) throws SQLException {
        Ticket t = new Ticket();
        t.setTicketId(rs.getInt("ticket_id"));
        t.setPnrNumber(rs.getString("pnr_number"));
        t.setUserId(rs.getInt("user_id"));
        t.setTrainId(rs.getInt("train_id"));
        t.setBookingDate(rs.getDate("booking_date"));
        t.setTravelDate(rs.getDate("travel_date"));
        t.setStatus(rs.getString("status"));
        t.setFare(rs.getBigDecimal("fare"));
        // Joined columns
        try { t.setTrainName(rs.getString("train_name")); } catch (SQLException ignored) {}
        try { t.setTrainNumber(rs.getString("train_number")); } catch (SQLException ignored) {}
        try { t.setSource(rs.getString("source")); } catch (SQLException ignored) {}
        try { t.setDestination(rs.getString("destination")); } catch (SQLException ignored) {}
        return t;
    }
}
