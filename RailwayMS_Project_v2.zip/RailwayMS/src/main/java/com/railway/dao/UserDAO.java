package com.railway.dao;

import com.railway.model.User;
import com.railway.util.DBConnection;

import java.sql.*;

/**
 * UserDAO – register, login, update password.
 *
 * NOTE: In a real project use BCrypt (org.mindrot:jbcrypt) to hash passwords.
 *       This demo stores plain text for simplicity; replace checkpw / hashpw calls.
 */
public class UserDAO {

    // ── Register ─────────────────────────────────────────────────────────
    public boolean registerUser(User user) throws SQLException {
        // Check duplicate email first
        if (emailExists(user.getEmail())) return false;

        String sql = "INSERT INTO users (name, email, password, phone, role) VALUES (?,?,?,?,?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, user.getName());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword()); // hash before storing in production
            ps.setString(4, user.getPhone());
            ps.setString(5, "user");

            return ps.executeUpdate() > 0;
        }
    }

    // ── Login ─────────────────────────────────────────────────────────────
    /**
     * Returns the User object on success, null on failure.
     * Replace plain-text comparison with BCrypt.checkpw() in production.
     */
    public User loginUser(String email, String password) throws SQLException {
        String sql = "SELECT * FROM users WHERE email = ? AND password = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    // ── Change password ───────────────────────────────────────────────────
    public boolean changePassword(int userId, String newPassword) throws SQLException {
        String sql = "UPDATE users SET password = ? WHERE user_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, newPassword);
            ps.setInt(2, userId);
            return ps.executeUpdate() > 0;
        }
    }

    // ── Helper ────────────────────────────────────────────────────────────
    private boolean emailExists(String email) throws SQLException {
        String sql = "SELECT 1 FROM users WHERE email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    private User mapRow(ResultSet rs) throws SQLException {
        User u = new User();
        u.setUserId(rs.getInt("user_id"));
        u.setName(rs.getString("name"));
        u.setEmail(rs.getString("email"));
        u.setPassword(rs.getString("password"));
        u.setPhone(rs.getString("phone"));
        u.setRole(rs.getString("role"));
        u.setCreatedAt(rs.getTimestamp("created_at"));
        return u;
    }
}
