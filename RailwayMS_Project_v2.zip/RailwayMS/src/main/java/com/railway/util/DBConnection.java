package com.railway.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DBConnection – singleton JDBC connection helper.
 * Update DB_URL, DB_USER, DB_PASSWORD before deployment.
 */
public class DBConnection {

    private static final String DB_URL      = "jdbc:mysql://localhost:3306/railway_db?useSSL=false&serverTimezone=Asia/Kolkata";
    private static final String DB_USER     = "root";
    private static final String DB_PASSWORD = "your_password_here";
    private static final String DRIVER      = "com.mysql.cj.jdbc.Driver";

    // Private constructor – utility class
    private DBConnection() {}

    /**
     * Returns a fresh JDBC Connection.
     * Each servlet/DAO calls getConnection() and closes it in a finally block.
     */
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC Driver not found. Add mysql-connector-j.jar to WEB-INF/lib.", e);
        }
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }
}
