package com.railway.servlet;

import com.railway.dao.ReportDAO;
import com.railway.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

/**
 * ReportServlet – GET /admin/reports
 * Loads all report data and forwards to reports.jsp.
 */
@WebServlet("/admin/reports")
public class ReportServlet extends HttpServlet {

    private final ReportDAO reportDAO = new ReportDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // Admin-only
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("loggedUser") : null;

        if (user == null || !"admin".equals(user.getRole())) {
            res.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        String type = req.getParameter("type");
        if (type == null) type = "daily";

        try {
            switch (type) {
                case "revenue":
                    req.setAttribute("revenueData", reportDAO.getRevenueByTrain());
                    break;
                case "cancellation":
                    req.setAttribute("cancellations", reportDAO.getCancellationReport());
                    break;
                default: // "daily"
                    req.setAttribute("dailyData", reportDAO.getDailyBookings());
                    break;
            }
            req.setAttribute("stats",       reportDAO.getSummaryStats());
            req.setAttribute("reportType",  type);
            req.getRequestDispatcher("/admin/reports.jsp").forward(req, res);

        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "Failed to load report: " + e.getMessage());
            req.getRequestDispatcher("/admin/reports.jsp").forward(req, res);
        }
    }
}
