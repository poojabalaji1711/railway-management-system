package com.railway.servlet;

import com.railway.dao.TrainDAO;
import com.railway.model.Train;
import com.railway.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.sql.Time;
import java.util.List;

/**
 * TrainServlet – admin CRUD for trains.
 * URL patterns:
 *   GET  /admin/trains          – list all trains
 *   POST /admin/trains?action=add    – add new train
 *   POST /admin/trains?action=update – update train
 *   POST /admin/trains?action=delete – delete train
 */
@WebServlet("/admin/trains")
public class TrainServlet extends HttpServlet {

    private final TrainDAO trainDAO = new TrainDAO();

    // ── GET: show train list ──────────────────────────────────────────────
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        if (!isAdmin(req, res)) return;

        try {
            List<Train> trains = trainDAO.getAllTrains();
            req.setAttribute("trains", trains);
            req.getRequestDispatcher("/admin/trains.jsp").forward(req, res);
        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "Could not load trains.");
            req.getRequestDispatcher("/admin/trains.jsp").forward(req, res);
        }
    }

    // ── POST: add / update / delete ───────────────────────────────────────
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        if (!isAdmin(req, res)) return;

        String action = req.getParameter("action");

        try {
            switch (action == null ? "" : action) {
                case "add":    addTrain(req, res);    break;
                case "update": updateTrain(req, res); break;
                case "delete": deleteTrain(req, res); break;
                default:
                    res.sendRedirect(req.getContextPath() + "/admin/trains");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "DB error: " + e.getMessage());
            req.getRequestDispatcher("/admin/trains.jsp").forward(req, res);
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private void addTrain(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException {

        Train t = buildTrainFromParams(req);
        trainDAO.addTrain(t);
        res.sendRedirect(req.getContextPath() + "/admin/trains?msg=Train+added+successfully");
    }

    private void updateTrain(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException, ServletException {

        Train t = buildTrainFromParams(req);
        t.setTrainId(Integer.parseInt(req.getParameter("trainId")));
        boolean ok = trainDAO.updateTrain(t);
        String msg = ok ? "Train+updated" : "Update+failed";
        res.sendRedirect(req.getContextPath() + "/admin/trains?msg=" + msg);
    }

    private void deleteTrain(HttpServletRequest req, HttpServletResponse res)
            throws SQLException, IOException {

        int id = Integer.parseInt(req.getParameter("trainId"));
        boolean ok = trainDAO.deleteTrain(id);
        String msg = ok ? "Train+deleted" : "Delete+failed";
        res.sendRedirect(req.getContextPath() + "/admin/trains?msg=" + msg);
    }

    private Train buildTrainFromParams(HttpServletRequest req) {
        Train t = new Train();
        t.setTrainNumber(req.getParameter("trainNumber"));
        t.setTrainName(req.getParameter("trainName"));
        t.setSource(req.getParameter("source"));
        t.setDestination(req.getParameter("destination"));
        t.setDepartureTime(Time.valueOf(req.getParameter("departureTime") + ":00"));
        t.setArrivalTime(Time.valueOf(req.getParameter("arrivalTime") + ":00"));
        t.setTotalSeats(Integer.parseInt(req.getParameter("totalSeats")));
        t.setFare(new BigDecimal(req.getParameter("fare")));
        return t;
    }

    /** Returns false and redirects to login if the session user is not admin. */
    private boolean isAdmin(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("loggedUser") : null;

        if (user == null || !"admin".equals(user.getRole())) {
            res.sendRedirect(req.getContextPath() + "/login.jsp");
            return false;
        }
        return true;
    }
}
