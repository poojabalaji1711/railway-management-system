package com.railway.servlet;

import com.railway.dao.UserDAO;
import com.railway.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

// ─────────────────────────────────────────────────────────────
//  LogoutServlet  –  GET /logout
// ─────────────────────────────────────────────────────────────
@WebServlet("/logout")
class LogoutServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {
        HttpSession session = req.getSession(false);
        if (session != null) session.invalidate();
        res.sendRedirect(req.getContextPath() + "/login.jsp");
    }
}

// ─────────────────────────────────────────────────────────────
//  RegisterServlet  –  GET/POST /register
// ─────────────────────────────────────────────────────────────
@WebServlet("/register")
class RegisterServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        req.getRequestDispatcher("/register.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String name     = req.getParameter("name");
        String email    = req.getParameter("email");
        String password = req.getParameter("password");
        String confirm  = req.getParameter("confirmPassword");
        String phone    = req.getParameter("phone");

        // Validation
        if (name == null || email == null || password == null || confirm == null
                || name.isBlank() || email.isBlank() || password.isBlank()) {
            req.setAttribute("error", "All fields are required.");
            req.getRequestDispatcher("/register.jsp").forward(req, res);
            return;
        }
        if (!password.equals(confirm)) {
            req.setAttribute("error", "Passwords do not match.");
            req.getRequestDispatcher("/register.jsp").forward(req, res);
            return;
        }
        if (password.length() < 6) {
            req.setAttribute("error", "Password must be at least 6 characters.");
            req.getRequestDispatcher("/register.jsp").forward(req, res);
            return;
        }

        try {
            User user = new User(name.trim(), email.trim(), password, phone, "user");
            boolean success = userDAO.registerUser(user);

            if (success) {
                req.setAttribute("success", "Registration successful! Please log in.");
                req.getRequestDispatcher("/login.jsp").forward(req, res);
            } else {
                req.setAttribute("error", "Email already registered. Please use a different email.");
                req.getRequestDispatcher("/register.jsp").forward(req, res);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "Server error. Please try again later.");
            req.getRequestDispatcher("/register.jsp").forward(req, res);
        }
    }
}
