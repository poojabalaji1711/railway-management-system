package com.railway.servlet;

import com.railway.dao.TrainDAO;
import com.railway.model.Train;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * SearchTrainServlet – handles GET /searchTrain
 * Reads 'source' and 'destination' params, queries DB, and forwards
 * results to searchResults.jsp.
 */
@WebServlet("/searchTrain")
public class SearchTrainServlet extends HttpServlet {

    private final TrainDAO trainDAO = new TrainDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String source      = req.getParameter("source");
        String destination = req.getParameter("destination");

        // If params are missing, show the search form
        if (source == null || source.isBlank() || destination == null || destination.isBlank()) {
            req.getRequestDispatcher("/user/searchForm.jsp").forward(req, res);
            return;
        }

        try {
            List<Train> results = trainDAO.searchTrains(source.trim(), destination.trim());

            req.setAttribute("trains",      results);
            req.setAttribute("source",      source);
            req.setAttribute("destination", destination);
            req.setAttribute("travelDate",  req.getParameter("travelDate"));

            req.getRequestDispatcher("/user/searchResults.jsp").forward(req, res);

        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "Search failed: " + e.getMessage());
            req.getRequestDispatcher("/user/searchResults.jsp").forward(req, res);
        }
    }
}
