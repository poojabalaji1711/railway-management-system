package com.railway.servlet;

import com.railway.dao.StationDAO;
import com.railway.model.Station;
import com.railway.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

/**
 * StationServlet – admin CRUD for stations.
 * GET  /admin/stations          → list all
 * POST /admin/stations?action=add    → add
 * POST /admin/stations?action=update → update
 * POST /admin/stations?action=delete → delete
 */
@WebServlet("/admin/stations")
public class StationServlet extends HttpServlet {

    private final StationDAO stationDAO = new StationDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        if (!isAdmin(req, res)) return;

        try {
            req.setAttribute("stations", stationDAO.getAllStations());
            req.getRequestDispatcher("/admin/stations.jsp").forward(req, res);
        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "Could not load stations: " + e.getMessage());
            req.getRequestDispatcher("/admin/stations.jsp").forward(req, res);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        if (!isAdmin(req, res)) return;

        String action = req.getParameter("action");

        try {
            switch (action == null ? "" : action) {
                case "add": {
                    Station s = new Station(
                        req.getParameter("stationName"),
                        req.getParameter("stationCode")
                    );
                    stationDAO.addStation(s);
                    res.sendRedirect(req.getContextPath() + "/admin/stations?msg=Station+added");
                    break;
                }
                case "update": {
                    Station s = new Station(
                        req.getParameter("stationName"),
                        req.getParameter("stationCode")
                    );
                    s.setStationId(Integer.parseInt(req.getParameter("stationId")));
                    stationDAO.updateStation(s);
                    res.sendRedirect(req.getContextPath() + "/admin/stations?msg=Station+updated");
                    break;
                }
                case "delete": {
                    stationDAO.deleteStation(Integer.parseInt(req.getParameter("stationId")));
                    res.sendRedirect(req.getContextPath() + "/admin/stations?msg=Station+deleted");
                    break;
                }
                default:
                    res.sendRedirect(req.getContextPath() + "/admin/stations");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "DB error: " + e.getMessage());
            req.getRequestDispatcher("/admin/stations.jsp").forward(req, res);
        }
    }

    private boolean isAdmin(HttpServletRequest req, HttpServletResponse res) throws IOException {
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("loggedUser") : null;
        if (user == null || !"admin".equals(user.getRole())) {
            res.sendRedirect(req.getContextPath() + "/login.jsp");
            return false;
        }
        return true;
    }
}
