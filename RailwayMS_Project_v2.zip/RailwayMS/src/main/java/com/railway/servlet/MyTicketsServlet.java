package com.railway.servlet;

import com.railway.dao.TicketDAO;
import com.railway.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

/**
 * MyTicketsServlet – GET /myTickets
 * Loads all tickets for the logged-in user and forwards to myTickets.jsp.
 */
@WebServlet("/myTickets")
public class MyTicketsServlet extends HttpServlet {

    private final TicketDAO ticketDAO = new TicketDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("loggedUser") : null;

        if (user == null) {
            res.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        try {
            req.setAttribute("tickets", ticketDAO.getTicketsByUser(user.getUserId()));
            req.getRequestDispatcher("/user/myTickets.jsp").forward(req, res);
        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "Could not load tickets: " + e.getMessage());
            req.getRequestDispatcher("/user/myTickets.jsp").forward(req, res);
        }
    }
}
