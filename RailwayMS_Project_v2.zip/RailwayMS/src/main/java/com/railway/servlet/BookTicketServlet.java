package com.railway.servlet;

import com.railway.dao.TicketDAO;
import com.railway.model.Ticket;
import com.railway.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;

/**
 * BookTicketServlet – handles POST /bookTicket
 * Validates input, generates PNR, delegates to TicketDAO.bookTicket().
 */
@WebServlet("/bookTicket")
public class BookTicketServlet extends HttpServlet {

    private final TicketDAO ticketDAO = new TicketDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // ── 1. Auth check ──────────────────────────────────────────────
        HttpSession session = req.getSession(false);
        User loggedUser = (session != null) ? (User) session.getAttribute("loggedUser") : null;

        if (loggedUser == null) {
            res.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        // ── 2. Read form parameters ────────────────────────────────────
        String trainIdStr   = req.getParameter("trainId");
        String travelDateStr = req.getParameter("travelDate");
        String fareStr       = req.getParameter("fare");
        String paymentMethod = req.getParameter("paymentMethod");

        // ── 3. Validate ────────────────────────────────────────────────
        if (trainIdStr == null || travelDateStr == null || fareStr == null) {
            req.setAttribute("error", "Missing booking details. Please go back and try again.");
            req.getRequestDispatcher("/booking.jsp").forward(req, res);
            return;
        }

        try {
            int     trainId    = Integer.parseInt(trainIdStr);
            Date    travelDate = Date.valueOf(travelDateStr);      // expects yyyy-MM-dd
            BigDecimal fare    = new BigDecimal(fareStr);

            // ── 4. Build Ticket object ─────────────────────────────────
            Ticket ticket = new Ticket();
            ticket.setPnrNumber(TicketDAO.generatePNR());
            ticket.setUserId(loggedUser.getUserId());
            ticket.setTrainId(trainId);
            ticket.setTravelDate(travelDate);
            ticket.setFare(fare);

            // ── 5. Persist (transactional) ─────────────────────────────
            int newTicketId = ticketDAO.bookTicket(ticket, paymentMethod != null ? paymentMethod : "Online");

            if (newTicketId > 0) {
                // Pass PNR to confirmation page
                session.setAttribute("lastPNR", ticket.getPnrNumber());
                res.sendRedirect(req.getContextPath() + "/user/bookingConfirmation.jsp");
            } else {
                req.setAttribute("error", "Booking failed. Seats may be full. Please try another train.");
                req.getRequestDispatcher("/booking.jsp").forward(req, res);
            }

        } catch (NumberFormatException e) {
            req.setAttribute("error", "Invalid input format.");
            req.getRequestDispatcher("/booking.jsp").forward(req, res);
        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "Database error: " + e.getMessage());
            req.getRequestDispatcher("/booking.jsp").forward(req, res);
        }
    }
}
