package com.railway.servlet;

import com.railway.dao.UserDAO;
import com.railway.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

/**
 * LoginServlet – handles POST /login
 * On success: sets session attribute "loggedUser" and redirects to dashboard.
 * On failure: forwards back to login.jsp with an error message.
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String email    = req.getParameter("email");
        String password = req.getParameter("password");

        // Basic input validation
        if (email == null || email.isBlank() || password == null || password.isBlank()) {
            req.setAttribute("error", "Email and password are required.");
            req.getRequestDispatcher("/login.jsp").forward(req, res);
            return;
        }

        try {
            User user = userDAO.loginUser(email.trim(), password);

            if (user != null) {
                // Create session
                HttpSession session = req.getSession(true);
                session.setAttribute("loggedUser", user);
                session.setMaxInactiveInterval(30 * 60); // 30 minutes

                // Redirect based on role
                if ("admin".equals(user.getRole())) {
                    res.sendRedirect(req.getContextPath() + "/admin/dashboard.jsp");
                } else {
                    res.sendRedirect(req.getContextPath() + "/user/dashboard.jsp");
                }

            } else {
                req.setAttribute("error", "Invalid email or password. Please try again.");
                req.getRequestDispatcher("/login.jsp").forward(req, res);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "Server error. Please try again later.");
            req.getRequestDispatcher("/login.jsp").forward(req, res);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        // Show the login page
        req.getRequestDispatcher("/login.jsp").forward(req, res);
    }
}
