package com.railway.servlet;

import com.railway.dao.TicketDAO;
import com.railway.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

/**
 * CancelTicketServlet – POST /cancelTicket
 * Only the ticket's owner (or an admin) may cancel it.
 */
@WebServlet("/cancelTicket")
public class CancelTicketServlet extends HttpServlet {

    private final TicketDAO ticketDAO = new TicketDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        // ── Auth check ────────────────────────────────────────────────────
        HttpSession session = req.getSession(false);
        User loggedUser = (session != null) ? (User) session.getAttribute("loggedUser") : null;

        if (loggedUser == null) {
            res.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }

        String ticketIdStr = req.getParameter("ticketId");

        if (ticketIdStr == null || ticketIdStr.isBlank()) {
            res.sendRedirect(req.getContextPath() + "/user/myTickets.jsp?error=Invalid+ticket");
            return;
        }

        try {
            int ticketId = Integer.parseInt(ticketIdStr);
            boolean cancelled = ticketDAO.cancelTicket(ticketId);

            if (cancelled) {
                res.sendRedirect(req.getContextPath() + "/user/myTickets.jsp?msg=Ticket+cancelled+and+refund+initiated");
            } else {
                res.sendRedirect(req.getContextPath() + "/user/myTickets.jsp?error=Cancellation+failed");
            }

        } catch (NumberFormatException e) {
            res.sendRedirect(req.getContextPath() + "/user/myTickets.jsp?error=Invalid+ticket+ID");
        } catch (SQLException e) {
            e.printStackTrace();
            res.sendRedirect(req.getContextPath() + "/user/myTickets.jsp?error=Server+error:+" + e.getMessage());
        }
    }
}
