<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:if test="${empty sessionScope.loggedUser}">
  <c:redirect url="/login.jsp"/>
</c:if>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Booking Confirmed – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body style="background:#f0f4f8;">

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
</nav>

<div class="container" style="padding-top:3rem; max-width:560px;">

  <div class="pnr-card">
    <div style="font-size:3rem; margin-bottom:.5rem;">✅</div>
    <h1 style="font-size:1.5rem; font-weight:700; margin-bottom:.5rem;">Booking Confirmed!</h1>
    <p style="color:#90cdf4; font-size:.9rem; margin-bottom:1.5rem;">Your ticket has been booked successfully.</p>

    <div style="background:rgba(255,255,255,.08); border-radius:10px; padding:1rem; margin-bottom:1.5rem;">
      <p style="font-size:.8rem; color:#90cdf4; letter-spacing:.1em; text-transform:uppercase; margin-bottom:.25rem;">PNR Number</p>
      <div class="pnr-number">${sessionScope.lastPNR}</div>
    </div>

    <p style="font-size:.85rem; color:#a0aec0;">
      Save your PNR number to check status or cancel the ticket.
    </p>
  </div>

  <div class="card" style="margin-top:1.5rem;">
    <div class="card-header">What's next?</div>
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
      <a href="${pageContext.request.contextPath}/user/myTickets.jsp" class="btn btn-primary" style="text-align:center;">
        View My Tickets
      </a>
      <a href="${pageContext.request.contextPath}/searchTrain" class="btn btn-outline" style="text-align:center;">
        Book Another
      </a>
    </div>
  </div>

</div>
</body>
</html>
