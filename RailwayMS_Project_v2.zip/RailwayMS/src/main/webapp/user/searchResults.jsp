<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Search Results – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
  <ul class="nav-links">
    <li><a href="${pageContext.request.contextPath}/searchTrain">Search</a></li>
    <li><a href="${pageContext.request.contextPath}/user/myTickets.jsp">My Tickets</a></li>
    <li><a href="${pageContext.request.contextPath}/logout">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:2rem;">

  <!-- Search box (repeat) -->
  <div class="card">
    <form action="${pageContext.request.contextPath}/searchTrain" method="get">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">From</label>
          <input type="text" name="source" class="form-control" value="${source}" required>
        </div>
        <div class="form-group">
          <label class="form-label">To</label>
          <input type="text" name="destination" class="form-control" value="${destination}" required>
        </div>
        <div class="form-group">
          <label class="form-label">Date</label>
          <input type="date" name="travelDate" class="form-control" value="${travelDate}">
        </div>
        <div class="form-group" style="display:flex; align-items:flex-end;">
          <button type="submit" class="btn btn-primary" style="width:100%;">Search</button>
        </div>
      </div>
    </form>
  </div>

  <h2 class="page-title">${source} → ${destination}</h2>
  <p class="page-sub" style="margin-bottom:1.5rem;">
    <c:choose>
      <c:when test="${empty trains}">No trains found for this route.</c:when>
      <c:otherwise>${trains.size()} train(s) found</c:otherwise>
    </c:choose>
  </p>

  <c:if test="${not empty error}">
    <div class="alert alert-danger">${error}</div>
  </c:if>

  <c:forEach var="train" items="${trains}">
    <div class="card" style="margin-bottom:1rem;">
      <div style="display:flex; flex-wrap:wrap; align-items:center; gap:1rem; justify-content:space-between;">
        <div>
          <span class="badge badge-info">${train.trainNumber}</span>
          <strong style="font-size:1.05rem; margin-left:.5rem;">${train.trainName}</strong>
        </div>
        <div style="display:flex; gap:2rem; flex-wrap:wrap; align-items:center;">
          <div style="text-align:center;">
            <div style="font-size:1.2rem; font-weight:700;">${train.departureTime}</div>
            <div style="font-size:.8rem; color:#718096;">${train.source}</div>
          </div>
          <div style="color:#cbd5e0;">→</div>
          <div style="text-align:center;">
            <div style="font-size:1.2rem; font-weight:700;">${train.arrivalTime}</div>
            <div style="font-size:.8rem; color:#718096;">${train.destination}</div>
          </div>
          <div>
            <c:choose>
              <c:when test="${train.availableSeats == 0}">
                <span class="badge badge-danger">No seats</span>
              </c:when>
              <c:when test="${train.availableSeats < 30}">
                <span class="badge badge-warning">${train.availableSeats} left</span>
              </c:when>
              <c:otherwise>
                <span class="badge badge-success">${train.availableSeats} available</span>
              </c:otherwise>
            </c:choose>
          </div>
          <div style="font-size:1.3rem; font-weight:700; color:#0d1b2a;">
            ₹<c:out value="${train.fare}"/>
          </div>
          <c:choose>
            <c:when test="${train.availableSeats > 0}">
              <a href="${pageContext.request.contextPath}/user/booking.jsp?trainId=${train.trainId}&travelDate=${travelDate}"
                 class="btn btn-primary">Book Now</a>
            </c:when>
            <c:otherwise>
              <button class="btn" disabled>Fully Booked</button>
            </c:otherwise>
          </c:choose>
        </div>
      </div>
    </div>
  </c:forEach>

</div>
</body>
</html>
