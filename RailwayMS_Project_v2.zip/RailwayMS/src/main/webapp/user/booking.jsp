<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%-- Auth guard --%>
<c:if test="${empty sessionScope.loggedUser}">
  <c:redirect url="/login.jsp"/>
</c:if>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Book Ticket – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
  <ul class="nav-links">
    <li><a href="${pageContext.request.contextPath}/searchTrain">Search</a></li>
    <li><a href="${pageContext.request.contextPath}/user/myTickets.jsp">My Tickets</a></li>
    <li><a href="${pageContext.request.contextPath}/logout">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:2rem;">
  <h1 class="page-title">Book Ticket</h1>
  <p class="page-sub" style="margin-bottom:1.5rem;">
    Train ID: ${param.trainId} &nbsp;·&nbsp; Travel date: ${param.travelDate}
  </p>

  <c:if test="${not empty requestScope.error}">
    <div class="alert alert-danger">${requestScope.error}</div>
  </c:if>

  <form action="${pageContext.request.contextPath}/bookTicket" method="post" id="bookingForm">
    <!-- Hidden fields -->
    <input type="hidden" name="trainId"     value="${param.trainId}">
    <input type="hidden" name="travelDate"  value="${param.travelDate}">
    <input type="hidden" name="selectedSeat" id="selectedSeatInput" value="">

    <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; flex-wrap:wrap;">

      <!-- Left: Passenger details -->
      <div class="card">
        <div class="card-header">Passenger details</div>

        <div class="form-group">
          <label class="form-label">Full name *</label>
          <input type="text" name="passengerName" class="form-control"
                 placeholder="As on ID proof" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Age *</label>
            <input type="number" name="age" class="form-control"
                   min="1" max="120" required>
          </div>
          <div class="form-group">
            <label class="form-label">Gender *</label>
            <select name="gender" class="form-control form-select" required>
              <option value="">Select</option>
              <option>Male</option>
              <option>Female</option>
              <option>Other</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Phone number *</label>
          <input type="tel" name="phone" class="form-control"
                 placeholder="10-digit mobile number" maxlength="10" required>
        </div>

        <!-- Ticket class selection -->
        <div class="form-group">
          <label class="form-label">Ticket class *</label>
          <select name="ticketClass" class="form-control form-select"
                  onchange="updateFare(this.value)" required>
            <option value="General" data-fare="185">General (₹185)</option>
            <option value="Sleeper" data-fare="680">Sleeper (₹680)</option>
            <option value="AC"      data-fare="1240" selected>AC 3-tier (₹1,240)</option>
          </select>
        </div>

        <!-- Payment method -->
        <div class="form-group">
          <label class="form-label">Payment method</label>
          <select name="paymentMethod" class="form-control form-select">
            <option value="UPI">UPI</option>
            <option value="Card">Debit / Credit Card</option>
            <option value="Net Banking">Net Banking</option>
          </select>
        </div>

        <!-- Hidden fare input updated by JS -->
        <input type="hidden" name="fare" id="fareInput" value="1240">
      </div>

      <!-- Right: Seat map + fare breakdown -->
      <div>
        <div class="card" style="margin-bottom:1rem;">
          <div class="card-header">Select seat (Coach S4)</div>
          <div class="seat-grid" id="seatGrid"></div>
          <p id="selectedSeatDisplay" style="font-size:.85rem; color:#2563eb; margin-top:.75rem; font-weight:600;"></p>
          <p style="font-size:.75rem; color:#718096; margin-top:.5rem;">
            <span style="display:inline-block; width:10px; height:10px; background:#dcfce7; border-radius:2px; margin-right:4px;"></span> Available &nbsp;
            <span style="display:inline-block; width:10px; height:10px; background:#fee2e2; border-radius:2px; margin-right:4px;"></span> Booked &nbsp;
            <span style="display:inline-block; width:10px; height:10px; background:#2563eb; border-radius:2px; margin-right:4px;"></span> Selected
          </p>
        </div>

        <div class="card">
          <div class="card-header">Fare breakdown</div>
          <div style="font-size:.9rem;">
            <div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #f0f4f8;">
              <span>Base fare</span><span id="baseFareDisplay">₹1,240</span>
            </div>
            <div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #f0f4f8;">
              <span>Reservation charge</span><span>₹40</span>
            </div>
            <div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #f0f4f8;">
              <span>GST (5%)</span><span id="gstDisplay">₹64</span>
            </div>
            <div style="display:flex; justify-content:space-between; padding:8px 0; font-weight:700; font-size:1rem;">
              <span>Total</span><span id="totalDisplay">₹1,344</span>
            </div>
          </div>
          <button type="submit" class="btn btn-primary" style="width:100%; margin-top:.75rem;"
                  onclick="return validateBooking()">
            Confirm &amp; Pay →
          </button>
        </div>
      </div>

    </div>
  </form>
</div>

<script src="${pageContext.request.contextPath}/js/main.js"></script>
<script>
// Build seat grid (seats 1-48; some pre-booked for demo)
const bookedSeats = [3, 7, 11, 15, 19, 22, 28, 31, 35, 42];
const grid = document.getElementById('seatGrid');
for (let i = 1; i <= 48; i++) {
  const el = document.createElement('div');
  el.className = 'seat ' + (bookedSeats.includes(i) ? 'seat-booked' : 'seat-available');
  el.textContent = i;
  el.onclick = function() { selectSeat(this, i); };
  grid.appendChild(el);
}

// Fare update
const fareMap = { 'General': 185, 'Sleeper': 680, 'AC': 1240 };
function updateFare(cls) {
  const base  = fareMap[cls] || 1240;
  const gst   = Math.round(base * 0.05);
  const total = base + 40 + gst;
  document.getElementById('fareInput').value = total;
  document.getElementById('baseFareDisplay').textContent = '₹' + base.toLocaleString('en-IN');
  document.getElementById('gstDisplay').textContent = '₹' + gst.toLocaleString('en-IN');
  document.getElementById('totalDisplay').textContent = '₹' + total.toLocaleString('en-IN');
}

function validateBooking() {
  if (!document.getElementById('selectedSeatInput').value) {
    alert('Please select a seat before confirming.');
    return false;
  }
  return true;
}
</script>
</body>
</html>
