<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%-- Auth guard --%>
<c:if test="${empty sessionScope.loggedUser}">
  <c:redirect url="/login.jsp"/>
</c:if>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
  <ul class="nav-links">
    <li><a href="${pageContext.request.contextPath}/searchTrain">Search Trains</a></li>
    <li><a href="${pageContext.request.contextPath}/user/myTickets.jsp" class="active">My Tickets</a></li>
    <li><a href="${pageContext.request.contextPath}/logout">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:2rem;">

  <div class="page-header">
    <h1 class="page-title">Welcome, ${sessionScope.loggedUser.name}!</h1>
    <p class="page-sub">Manage your bookings and search for trains</p>
  </div>

  <!-- Quick actions -->
  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-icon" style="background:#dbeafe;">🎫</div>
      <div class="stat-value" style="color:#2563eb;">—</div>
      <div class="stat-label">Active tickets</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:#dcfce7;">🚉</div>
      <div class="stat-value" style="color:#16a34a;">48</div>
      <div class="stat-label">Trains available</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:#fef9c3;">⚡</div>
      <div class="stat-value" style="color:#a16207;">3 mins</div>
      <div class="stat-label">Avg. booking time</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:#fee2e2;">📞</div>
      <div class="stat-value" style="color:#dc2626;">139</div>
      <div class="stat-label">Helpline</div>
    </div>
  </div>

  <!-- Search form shortcut -->
  <div class="card">
    <div class="card-header">Book a new ticket</div>
    <form action="${pageContext.request.contextPath}/searchTrain" method="get">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">From station</label>
          <select name="source" class="form-control form-select" required>
            <option value="">Select source</option>
            <option>Chennai Central</option>
            <option>New Delhi</option>
            <option>Mumbai CST</option>
            <option>Bangalore City</option>
            <option>Howrah Junction</option>
            <option>Hyderabad Deccan</option>
            <option>Ahmedabad Junction</option>
            <option>Pune Junction</option>
            <option>Tirupati</option>
            <option>Vijayawada Junction</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">To station</label>
          <select name="destination" class="form-control form-select" required>
            <option value="">Select destination</option>
            <option>New Delhi</option>
            <option>Chennai Central</option>
            <option>Howrah Junction</option>
            <option>Bangalore City</option>
            <option>Mumbai CST</option>
            <option>Hyderabad Deccan</option>
            <option>Ahmedabad Junction</option>
            <option>Pune Junction</option>
            <option>Tirupati</option>
            <option>Vijayawada Junction</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Travel date</label>
          <input type="date" name="travelDate" class="form-control" id="travelDate" required>
        </div>
        <div class="form-group" style="display:flex; align-items:flex-end;">
          <button type="submit" class="btn btn-primary" style="width:100%;">Search Trains →</button>
        </div>
      </div>
    </form>
  </div>

</div>

<script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
