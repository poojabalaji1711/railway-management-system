<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%-- Auth guard --%>
<c:if test="${empty sessionScope.loggedUser}">
  <c:redirect url="/login.jsp"/>
</c:if>
<%--
  This page is reached from the MyTicketsServlet (GET /myTickets)
  which sets request attribute "tickets" = List<Ticket>.
  For simplicity, the page also shows a direct DB lookup via JSTL
  if the servlet sets the list; otherwise it shows an empty state.
--%>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Tickets – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
  <ul class="nav-links">
    <li><a href="${pageContext.request.contextPath}/user/dashboard.jsp">Dashboard</a></li>
    <li><a href="${pageContext.request.contextPath}/searchTrain">Search</a></li>
    <li><a href="${pageContext.request.contextPath}/user/myTickets.jsp" class="active">My Tickets</a></li>
    <li><a href="${pageContext.request.contextPath}/logout">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:2rem;">

  <div class="page-header">
    <h1 class="page-title">My Tickets</h1>
    <p class="page-sub">All your bookings in one place</p>
  </div>

  <c:if test="${not empty param.msg}">
    <div class="alert alert-success">${param.msg}</div>
  </c:if>
  <c:if test="${not empty param.error}">
    <div class="alert alert-danger">${param.error}</div>
  </c:if>

  <div class="card">
    <c:choose>
      <c:when test="${empty tickets}">
        <div style="text-align:center; padding:3rem; color:#718096;">
          <div style="font-size:3rem; margin-bottom:1rem;">🎫</div>
          <h3>No tickets yet</h3>
          <p style="margin:.5rem 0 1.5rem;">You haven't booked any tickets.</p>
          <a href="${pageContext.request.contextPath}/searchTrain" class="btn btn-primary">
            Search &amp; Book Trains
          </a>
        </div>
      </c:when>
      <c:otherwise>
        <div class="table-responsive">
          <table>
            <thead>
              <tr>
                <th>PNR</th>
                <th>Train</th>
                <th>Route</th>
                <th>Travel date</th>
                <th>Class</th>
                <th>Fare (₹)</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <c:forEach var="ticket" items="${tickets}">
                <tr>
                  <td><strong>${ticket.pnrNumber}</strong></td>
                  <td>
                    <div style="font-size:.85rem; font-weight:600;">${ticket.trainName}</div>
                    <div style="font-size:.75rem; color:#718096;">${ticket.trainNumber}</div>
                  </td>
                  <td>${ticket.source} → ${ticket.destination}</td>
                  <td>${ticket.travelDate}</td>
                  <td>—</td>
                  <td>
                    <fmt:formatNumber value="${ticket.fare}" type="number" minFractionDigits="2" maxFractionDigits="2"/>
                  </td>
                  <td>
                    <c:choose>
                      <c:when test="${ticket.status == 'Confirmed'}">
                        <span class="badge badge-success">Confirmed</span>
                      </c:when>
                      <c:when test="${ticket.status == 'Waiting'}">
                        <span class="badge badge-warning">Waiting</span>
                      </c:when>
                      <c:otherwise>
                        <span class="badge badge-danger">Cancelled</span>
                      </c:otherwise>
                    </c:choose>
                  </td>
                  <td>
                    <c:if test="${ticket.status == 'Confirmed' || ticket.status == 'Waiting'}">
                      <form action="${pageContext.request.contextPath}/cancelTicket"
                            method="post" style="display:inline;">
                        <input type="hidden" name="ticketId" value="${ticket.ticketId}">
                        <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Cancel ticket ${ticket.pnrNumber}? This will initiate a refund.')">
                          Cancel
                        </button>
                      </form>
                    </c:if>
                  </td>
                </tr>
              </c:forEach>
            </tbody>
          </table>
        </div>
      </c:otherwise>
    </c:choose>
  </div>

</div>
</body>
</html>
