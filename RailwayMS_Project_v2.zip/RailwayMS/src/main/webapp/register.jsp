<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body style="background:#f0f4f8; min-height:100vh; display:flex; flex-direction:column;">

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
  <ul class="nav-links">
    <li><a href="${pageContext.request.contextPath}/login.jsp">Login</a></li>
  </ul>
</nav>

<main style="flex:1; display:flex; align-items:center; justify-content:center; padding:2rem;">
  <div style="width:100%; max-width:480px;">
    <div class="card">
      <h1 style="font-size:1.5rem; font-weight:700; margin-bottom:.25rem;">Create account</h1>
      <p style="color:#718096; margin-bottom:1.5rem; font-size:.9rem;">Join RailMS to book train tickets</p>

      <c:if test="${not empty requestScope.error}">
        <div class="alert alert-danger">${requestScope.error}</div>
      </c:if>
      <c:if test="${not empty requestScope.success}">
        <div class="alert alert-success">${requestScope.success}</div>
      </c:if>

      <form action="${pageContext.request.contextPath}/register" method="post" id="registerForm">
        <div class="form-row">
          <div class="form-group">
            <label class="form-label" for="regName">Full name *</label>
            <input type="text" id="regName" name="name" class="form-control"
                   placeholder="Ravi Kumar" required autocomplete="name">
          </div>
          <div class="form-group">
            <label class="form-label" for="regPhone">Phone number</label>
            <input type="tel" id="regPhone" name="phone" class="form-control"
                   placeholder="9876543210" maxlength="10">
          </div>
        </div>

        <div class="form-group">
          <label class="form-label" for="regEmail">Email address *</label>
          <input type="email" id="regEmail" name="email" class="form-control"
                 placeholder="you@example.com" required autocomplete="email">
        </div>

        <div class="form-row">
          <div class="form-group">
            <label class="form-label" for="regPassword">Password *</label>
            <input type="password" id="regPassword" name="password" class="form-control"
                   placeholder="Min. 6 characters" required minlength="6" autocomplete="new-password">
          </div>
          <div class="form-group">
            <label class="form-label" for="confirmPassword">Confirm password *</label>
            <input type="password" id="confirmPassword" name="confirmPassword" class="form-control"
                   placeholder="Repeat password" required autocomplete="new-password">
          </div>
        </div>

        <button type="submit" class="btn btn-primary" style="width:100%; margin-top:.5rem;">
          Create account
        </button>
      </form>

      <p style="text-align:center; margin-top:1.25rem; font-size:.9rem; color:#718096;">
        Already have an account? <a href="${pageContext.request.contextPath}/login.jsp" style="color:#2563eb;">Sign in</a>
      </p>
    </div>
  </div>
</main>

<script src="${pageContext.request.contextPath}/js/main.js"></script>
</body>
</html>
