<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RailMS – Railway Management System</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
  <ul class="nav-links">
    <c:choose>
      <c:when test="${not empty sessionScope.loggedUser}">
        <li><a href="${pageContext.request.contextPath}/user/dashboard.jsp">Dashboard</a></li>
        <li><a href="${pageContext.request.contextPath}/searchTrain">Search Trains</a></li>
        <li><a href="${pageContext.request.contextPath}/logout">Logout (${sessionScope.loggedUser.name})</a></li>
      </c:when>
      <c:otherwise>
        <li><a href="${pageContext.request.contextPath}/login.jsp">Login</a></li>
        <li><a href="${pageContext.request.contextPath}/register.jsp">Register</a></li>
      </c:otherwise>
    </c:choose>
  </ul>
</nav>

<!-- Hero -->
<section style="background:#0d1b2a; color:#fff; padding:5rem 1rem; text-align:center;">
  <h1 style="font-size:3rem; font-weight:800; margin-bottom:1rem;">Book Train Tickets <span style="color:#e63946;">Instantly</span></h1>
  <p style="font-size:1.2rem; color:#a0aec0; max-width:560px; margin:0 auto 2rem;">
    Search trains, check seat availability, and book tickets in seconds.
  </p>

  <!-- Quick search form -->
  <form action="${pageContext.request.contextPath}/searchTrain" method="get"
        style="display:flex; flex-wrap:wrap; gap:.75rem; justify-content:center; max-width:700px; margin:0 auto;">
    <select name="source" class="form-control form-select" style="flex:1; min-width:150px; background:#1a365d; color:#fff; border-color:#2d3748;">
      <option value="">From</option>
      <option>Chennai Central</option>
      <option>New Delhi</option>
      <option>Mumbai CST</option>
      <option>Bangalore City</option>
      <option>Howrah Junction</option>
      <option>Hyderabad Deccan</option>
    </select>
    <select name="destination" class="form-control form-select" style="flex:1; min-width:150px; background:#1a365d; color:#fff; border-color:#2d3748;">
      <option value="">To</option>
      <option>New Delhi</option>
      <option>Chennai Central</option>
      <option>Howrah Junction</option>
      <option>Bangalore City</option>
      <option>Mumbai CST</option>
      <option>Hyderabad Deccan</option>
    </select>
    <input type="date" name="travelDate" class="form-control" min="<%= java.time.LocalDate.now() %>"
           style="flex:1; min-width:150px; background:#1a365d; color:#fff; border-color:#2d3748;">
    <button type="submit" class="btn btn-primary" style="padding:.6rem 2rem;">Search Trains</button>
  </form>
</section>

<!-- Features -->
<section class="container" style="padding:4rem 1rem;">
  <h2 style="text-align:center; margin-bottom:2.5rem; font-size:1.6rem;">Everything you need</h2>
  <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:1.5rem;">
    <div class="card" style="text-align:center;">
      <div style="font-size:2.5rem; margin-bottom:.75rem;">🔍</div>
      <h3>Smart Search</h3>
      <p style="color:#718096; font-size:.9rem; margin-top:.5rem;">Search by source, destination, train number, or name.</p>
    </div>
    <div class="card" style="text-align:center;">
      <div style="font-size:2.5rem; margin-bottom:.75rem;">🎫</div>
      <h3>Instant Booking</h3>
      <p style="color:#718096; font-size:.9rem; margin-top:.5rem;">Book in 3 steps and get your PNR immediately.</p>
    </div>
    <div class="card" style="text-align:center;">
      <div style="font-size:2.5rem; margin-bottom:.75rem;">💺</div>
      <h3>Seat Selection</h3>
      <p style="color:#718096; font-size:.9rem; margin-top:.5rem;">Choose your preferred seat with our visual seat map.</p>
    </div>
    <div class="card" style="text-align:center;">
      <div style="font-size:2.5rem; margin-bottom:.75rem;">❌</div>
      <h3>Easy Cancellation</h3>
      <p style="color:#718096; font-size:.9rem; margin-top:.5rem;">Cancel anytime and receive automatic refund processing.</p>
    </div>
  </div>
</section>

<footer style="background:#0d1b2a; color:#718096; text-align:center; padding:2rem; font-size:.85rem;">
  © 2026 RailMS – Railway Management System. College Final Year Project.
</footer>

</body>
</html>
