/* ============================================================
   RailMS – main.js
   Client-side validation, form helpers, and UI interactions
   ============================================================ */

// ── Form validation ───────────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {

  // Login form
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
      const email = document.getElementById('email').value.trim();
      const pw    = document.getElementById('password').value;
      if (!email || !pw) {
        e.preventDefault();
        showError('Please fill in all fields.');
      } else if (!isValidEmail(email)) {
        e.preventDefault();
        showError('Please enter a valid email address.');
      }
    });
  }

  // Registration form
  const regForm = document.getElementById('registerForm');
  if (regForm) {
    regForm.addEventListener('submit', function (e) {
      const name    = document.getElementById('regName').value.trim();
      const email   = document.getElementById('regEmail').value.trim();
      const pw      = document.getElementById('regPassword').value;
      const confirm = document.getElementById('confirmPassword').value;
      const phone   = document.getElementById('regPhone').value.trim();

      if (!name || !email || !pw || !confirm) {
        e.preventDefault();
        showError('All fields are required.');
        return;
      }
      if (!isValidEmail(email)) {
        e.preventDefault();
        showError('Enter a valid email address.');
        return;
      }
      if (pw.length < 6) {
        e.preventDefault();
        showError('Password must be at least 6 characters.');
        return;
      }
      if (pw !== confirm) {
        e.preventDefault();
        showError('Passwords do not match.');
        return;
      }
      if (phone && !/^\d{10}$/.test(phone)) {
        e.preventDefault();
        showError('Phone number must be 10 digits.');
      }
    });
  }

  // Booking form – prevent past dates
  const travelDateInput = document.getElementById('travelDate');
  if (travelDateInput) {
    const today = new Date().toISOString().split('T')[0];
    travelDateInput.setAttribute('min', today);
    travelDateInput.addEventListener('change', function () {
      if (this.value < today) {
        this.value = today;
        showError('Travel date cannot be in the past.');
      }
    });
  }

  // Auto-dismiss alerts after 5 seconds
  document.querySelectorAll('.alert').forEach(function (alert) {
    setTimeout(function () {
      alert.style.transition = 'opacity .5s';
      alert.style.opacity = '0';
      setTimeout(function () { alert.remove(); }, 500);
    }, 5000);
  });
});

// ── Seat selection ────────────────────────────────────────
var selectedSeat = null;

function selectSeat(el, seatNumber) {
  if (el.classList.contains('seat-booked')) return;

  // Deselect previous
  document.querySelectorAll('.seat-selected').forEach(function (s) {
    s.classList.remove('seat-selected');
    s.classList.add('seat-available');
  });

  el.classList.remove('seat-available');
  el.classList.add('seat-selected');
  selectedSeat = seatNumber;

  const seatInput = document.getElementById('selectedSeatInput');
  if (seatInput) seatInput.value = seatNumber;

  document.getElementById('selectedSeatDisplay').textContent = 'Seat ' + seatNumber + ' selected';
}

// ── Search form swap source/destination ──────────────────
function swapStations() {
  const src = document.getElementById('sourceInput');
  const dst = document.getElementById('destinationInput');
  if (src && dst) {
    const tmp = src.value;
    src.value = dst.value;
    dst.value = tmp;
  }
}

// ── Payment simulation ────────────────────────────────────
function simulatePayment(formId) {
  const form = document.getElementById(formId);
  const btn  = form ? form.querySelector('[type=submit]') : null;
  if (btn) {
    btn.textContent = 'Processing…';
    btn.disabled = true;
    setTimeout(function () { form.submit(); }, 1500);
  }
}

// ── Utilities ─────────────────────────────────────────────
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function showError(msg) {
  let el = document.getElementById('jsError');
  if (!el) {
    el = document.createElement('div');
    el.id = 'jsError';
    el.className = 'alert alert-danger';
    const firstCard = document.querySelector('.card');
    if (firstCard) firstCard.prepend(el);
    else document.body.prepend(el);
  }
  el.textContent = msg;
  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function confirmAction(message) {
  return confirm(message || 'Are you sure?');
}
