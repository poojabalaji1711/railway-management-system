<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body style="background:#f0f4f8; min-height:100vh; display:flex; flex-direction:column;">

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
</nav>

<main style="flex:1; display:flex; align-items:center; justify-content:center; padding:2rem;">
  <div style="width:100%; max-width:420px;">
    <div class="card">
      <h1 style="font-size:1.5rem; font-weight:700; margin-bottom:.25rem;">Welcome back</h1>
      <p style="color:#718096; margin-bottom:1.5rem; font-size:.9rem;">Sign in to your RailMS account</p>

      <!-- Error alert -->
      <c:if test="${not empty requestScope.error}">
        <div class="alert alert-danger">${requestScope.error}</div>
      </c:if>

      <form action="${pageContext.request.contextPath}/login" method="post" id="loginForm">
        <div class="form-group">
          <label class="form-label" for="email">Email address</label>
          <input type="email" id="email" name="email" class="form-control"
                 placeholder="you@example.com" required autocomplete="email">
        </div>
        <div class="form-group">
          <label class="form-label" for="password">Password</label>
          <input type="password" id="password" name="password" class="form-control"
                 placeholder="••••••••" required autocomplete="current-password">
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%; margin-top:.5rem;">Sign in</button>
      </form>

      <p style="text-align:center; margin-top:1.25rem; font-size:.9rem; color:#718096;">
        No account? <a href="${pageContext.request.contextPath}/register.jsp" style="color:#2563eb;">Register here</a>
      </p>

      <!-- Demo credentials hint for college demo -->
      <div class="alert alert-info" style="margin-top:1rem; font-size:.8rem;">
        <strong>Demo — Admin:</strong> admin@railway.com / password123<br>
        <strong>Demo — User:</strong> ravi@example.com / password123
      </div>
    </div>
  </div>
</main>

<script>
// Simple client-side validation
document.getElementById('loginForm').addEventListener('submit', function(e) {
  const email = document.getElementById('email').value.trim();
  const pw    = document.getElementById('password').value;
  if (!email || !pw) {
    e.preventDefault();
    alert('Please fill in all fields.');
  }
});
</script>
</body>
</html>
