<%@ page contentType="text/html;charset=UTF-8" language="java" isErrorPage="true" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Error – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body style="background:#f0f4f8; min-height:100vh; display:flex; flex-direction:column; align-items:center; justify-content:center;">
  <div style="text-align:center; max-width:480px;">
    <div style="font-size:5rem; margin-bottom:1rem;">🚂</div>
    <h1 style="font-size:2rem; font-weight:700; margin-bottom:.5rem;">
      <%= request.getAttribute("javax.servlet.error.status_code") != null
          ? request.getAttribute("javax.servlet.error.status_code") : "Error" %>
    </h1>
    <p style="color:#718096; margin-bottom:2rem;">
      <%= request.getAttribute("javax.servlet.error.message") != null
          ? request.getAttribute("javax.servlet.error.message") : "Something went wrong." %>
    </p>
    <a href="${pageContext.request.contextPath}/" class="btn btn-primary">← Back to Home</a>
  </div>
</body>
</html>
