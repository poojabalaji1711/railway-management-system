<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<c:if test="${empty sessionScope.loggedUser || sessionScope.loggedUser.role != 'admin'}">
  <c:redirect url="/login.jsp"/>
</c:if>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Stations – Admin – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
  <ul class="nav-links">
    <li><a href="${pageContext.request.contextPath}/admin/dashboard.jsp">Dashboard</a></li>
    <li><a href="${pageContext.request.contextPath}/admin/trains">Trains</a></li>
    <li><a href="${pageContext.request.contextPath}/admin/stations" class="active">Stations</a></li>
    <li><a href="${pageContext.request.contextPath}/logout">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:2rem;">
  <div class="page-header" style="display:flex; justify-content:space-between; align-items:center;">
    <div>
      <h1 class="page-title">Manage Stations</h1>
      <p class="page-sub">Add, update, or remove railway stations</p>
    </div>
    <button class="btn btn-primary" onclick="document.getElementById('addModal').style.display='flex'">
      + Add Station
    </button>
  </div>

  <c:if test="${not empty param.msg}">
    <div class="alert alert-success">${param.msg}</div>
  </c:if>
  <c:if test="${not empty error}">
    <div class="alert alert-danger">${error}</div>
  </c:if>

  <div class="card">
    <div class="table-responsive">
      <table>
        <thead>
          <tr><th>#</th><th>Station Name</th><th>Station Code</th><th>Action</th></tr>
        </thead>
        <tbody>
          <c:forEach var="s" items="${stations}" varStatus="loop">
            <tr>
              <td>${loop.count}</td>
              <td>${s.stationName}</td>
              <td><span class="badge badge-info">${s.stationCode}</span></td>
              <td>
                <form action="${pageContext.request.contextPath}/admin/stations" method="post" style="display:inline;">
                  <input type="hidden" name="action"    value="delete">
                  <input type="hidden" name="stationId" value="${s.stationId}">
                  <button type="submit" class="btn btn-danger btn-sm"
                          onclick="return confirm('Delete ${s.stationName}?')">Delete</button>
                </form>
              </td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Add Station Modal -->
<div id="addModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.5);
     align-items:center; justify-content:center; z-index:9999;">
  <div class="card" style="width:420px; max-width:95vw;">
    <div class="card-header">
      <span>Add Station</span>
      <button onclick="document.getElementById('addModal').style.display='none'"
              style="background:none; border:none; font-size:1.2rem; cursor:pointer;">✕</button>
    </div>
    <form action="${pageContext.request.contextPath}/admin/stations" method="post">
      <input type="hidden" name="action" value="add">
      <div class="form-group">
        <label class="form-label">Station Name *</label>
        <input type="text" name="stationName" class="form-control" placeholder="e.g. Chennai Central" required>
      </div>
      <div class="form-group">
        <label class="form-label">Station Code *</label>
        <input type="text" name="stationCode" class="form-control" placeholder="e.g. MAS" maxlength="10" required>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;">Add Station</button>
    </form>
  </div>
</div>

</body>
</html>
