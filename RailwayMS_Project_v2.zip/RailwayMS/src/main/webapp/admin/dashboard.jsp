<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%-- Admin guard --%>
<c:if test="${empty sessionScope.loggedUser || sessionScope.loggedUser.role != 'admin'}">
  <c:redirect url="/login.jsp"/>
</c:if>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Dashboard – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
  <ul class="nav-links">
    <li><a href="${pageContext.request.contextPath}/admin/dashboard.jsp" class="active">Dashboard</a></li>
    <li><a href="${pageContext.request.contextPath}/admin/trains">Trains</a></li>
    <li><a href="${pageContext.request.contextPath}/admin/stations">Stations</a></li>
    <li><a href="${pageContext.request.contextPath}/admin/reports?type=daily">Reports</a></li>
    <li><a href="${pageContext.request.contextPath}/logout">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:2rem;">

  <div class="page-header">
    <h1 class="page-title">Admin Dashboard</h1>
    <p class="page-sub">Logged in as ${sessionScope.loggedUser.name}</p>
  </div>

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card">
      <div class="stat-icon" style="background:#dbeafe;">🚂</div>
      <div class="stat-value" id="statTrains">—</div>
      <div class="stat-label">Total trains</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:#dcfce7;">🎫</div>
      <div class="stat-value" id="statBookings">—</div>
      <div class="stat-label">Total bookings</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:#fef9c3;">💰</div>
      <div class="stat-value" id="statRevenue">—</div>
      <div class="stat-label">Total revenue</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:#fee2e2;">❌</div>
      <div class="stat-value" id="statCancellations">—</div>
      <div class="stat-label">Cancellations</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="background:#f3e8ff;">👥</div>
      <div class="stat-value" id="statUsers">—</div>
      <div class="stat-label">Registered users</div>
    </div>
  </div>

  <!-- Quick links -->
  <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:1rem; margin-bottom:2rem;">
    <a href="${pageContext.request.contextPath}/admin/trains" class="card" style="text-decoration:none; text-align:center; cursor:pointer;">
      <div style="font-size:2rem; margin-bottom:.5rem;">🚆</div>
      <div style="font-weight:600;">Manage Trains</div>
      <div style="font-size:.8rem; color:#718096; margin-top:.25rem;">Add · Edit · Delete</div>
    </a>
    <a href="${pageContext.request.contextPath}/admin/stations" class="card" style="text-decoration:none; text-align:center; cursor:pointer;">
      <div style="font-size:2rem; margin-bottom:.5rem;">🚉</div>
      <div style="font-weight:600;">Manage Stations</div>
      <div style="font-size:.8rem; color:#718096; margin-top:.25rem;">Add · Edit · Delete</div>
    </a>
    <a href="${pageContext.request.contextPath}/admin/reports?type=daily" class="card" style="text-decoration:none; text-align:center; cursor:pointer;">
      <div style="font-size:2rem; margin-bottom:.5rem;">📊</div>
      <div style="font-weight:600;">Daily Report</div>
      <div style="font-size:.8rem; color:#718096; margin-top:.25rem;">Bookings · Revenue</div>
    </a>
    <a href="${pageContext.request.contextPath}/admin/reports?type=revenue" class="card" style="text-decoration:none; text-align:center; cursor:pointer;">
      <div style="font-size:2rem; margin-bottom:.5rem;">💹</div>
      <div style="font-weight:600;">Revenue Report</div>
      <div style="font-size:.8rem; color:#718096; margin-top:.25rem;">By train</div>
    </a>
    <a href="${pageContext.request.contextPath}/admin/reports?type=cancellation" class="card" style="text-decoration:none; text-align:center; cursor:pointer;">
      <div style="font-size:2rem; margin-bottom:.5rem;">🔄</div>
      <div style="font-weight:600;">Cancellations</div>
      <div style="font-size:.8rem; color:#718096; margin-top:.25rem;">Refund status</div>
    </a>
  </div>

</div>

<%-- Load stats via ReportServlet AJAX (or simply include stats if forwarded) --%>
<script>
// If stats were passed as request attributes (from AdminDashboardServlet), display them.
// Otherwise show defaults. Extend by creating an AdminDashboardServlet that sets these.
const statsEl = {
  trains:        document.getElementById('statTrains'),
  bookings:      document.getElementById('statBookings'),
  revenue:       document.getElementById('statRevenue'),
  cancellations: document.getElementById('statCancellations'),
  users:         document.getElementById('statUsers')
};
// Values injected from ReportServlet if dashboard loads through it:
<%
  Object stats = request.getAttribute("stats");
  if (stats instanceof java.util.Map) {
    java.util.Map<?,?> m = (java.util.Map<?,?>) stats;
%>
statsEl.trains.textContent        = '<%= m.get("totalTrains") %>';
statsEl.bookings.textContent      = '<%= m.get("totalBookings") %>';
statsEl.revenue.textContent       = '₹<%= m.get("totalRevenue") %>';
statsEl.cancellations.textContent = '<%= m.get("cancellations") %>';
statsEl.users.textContent         = '<%= m.get("totalUsers") %>';
<%
  } else {
%>
// Fallback: display placeholder text
Object.values(statsEl).forEach(function(el){ el.textContent = '—'; });
<%
  }
%>
</script>
</body>
</html>
