<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Trains – Admin – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
  <ul class="nav-links">
    <li><a href="${pageContext.request.contextPath}/admin/dashboard.jsp">Dashboard</a></li>
    <li><a href="${pageContext.request.contextPath}/admin/trains" class="active">Trains</a></li>
    <li><a href="${pageContext.request.contextPath}/logout">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:2rem;">

  <div class="page-header" style="display:flex; justify-content:space-between; align-items:center;">
    <div>
      <h1 class="page-title">Manage Trains</h1>
      <p class="page-sub">Add, edit, or remove trains from the system</p>
    </div>
    <button class="btn btn-primary" onclick="document.getElementById('addModal').style.display='flex'">
      + Add New Train
    </button>
  </div>

  <c:if test="${not empty param.msg}">
    <div class="alert alert-success">${param.msg}</div>
  </c:if>
  <c:if test="${not empty error}">
    <div class="alert alert-danger">${error}</div>
  </c:if>

  <!-- Train Table -->
  <div class="card">
    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>Train No.</th><th>Name</th><th>From</th><th>To</th>
            <th>Departure</th><th>Arrival</th><th>Seats</th><th>Fare</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <c:forEach var="t" items="${trains}">
            <tr>
              <td><span class="badge badge-info">${t.trainNumber}</span></td>
              <td><strong>${t.trainName}</strong></td>
              <td>${t.source}</td>
              <td>${t.destination}</td>
              <td>${t.departureTime}</td>
              <td>${t.arrivalTime}</td>
              <td>
                <c:choose>
                  <c:when test="${t.availableSeats == 0}"><span class="badge badge-danger">Full</span></c:when>
                  <c:when test="${t.availableSeats < 30}"><span class="badge badge-warning">${t.availableSeats}</span></c:when>
                  <c:otherwise><span class="badge badge-success">${t.availableSeats}</span></c:otherwise>
                </c:choose>
                / ${t.totalSeats}
              </td>
              <td>₹${t.fare}</td>
              <td style="display:flex; gap:.5rem;">
                <form action="${pageContext.request.contextPath}/admin/trains" method="post" style="display:inline;">
                  <input type="hidden" name="action" value="delete">
                  <input type="hidden" name="trainId" value="${t.trainId}">
                  <button type="submit" class="btn btn-danger btn-sm"
                          onclick="return confirm('Delete ${t.trainName}?')">Delete</button>
                </form>
              </td>
            </tr>
          </c:forEach>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Add Train Modal (simple show/hide) -->
<div id="addModal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.5);
     align-items:center; justify-content:center; z-index:9999;">
  <div class="card" style="width:600px; max-width:95vw; max-height:90vh; overflow-y:auto;">
    <div class="card-header">
      <span>Add New Train</span>
      <button onclick="document.getElementById('addModal').style.display='none'" style="background:none; border:none; font-size:1.2rem; cursor:pointer;">✕</button>
    </div>
    <form action="${pageContext.request.contextPath}/admin/trains" method="post">
      <input type="hidden" name="action" value="add">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Train Number</label>
          <input type="text" name="trainNumber" class="form-control" placeholder="12621" required>
        </div>
        <div class="form-group">
          <label class="form-label">Train Name</label>
          <input type="text" name="trainName" class="form-control" placeholder="Tamil Nadu Express" required>
        </div>
        <div class="form-group">
          <label class="form-label">Source Station</label>
          <input type="text" name="source" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Destination Station</label>
          <input type="text" name="destination" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Departure Time (HH:MM)</label>
          <input type="time" name="departureTime" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Arrival Time (HH:MM)</label>
          <input type="time" name="arrivalTime" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Total Seats</label>
          <input type="number" name="totalSeats" class="form-control" value="200" min="1" required>
        </div>
        <div class="form-group">
          <label class="form-label">Fare (₹)</label>
          <input type="number" name="fare" class="form-control" step="0.01" min="0" required>
        </div>
      </div>
      <button type="submit" class="btn btn-primary" style="width:100%;">Add Train</button>
    </form>
  </div>
</div>

</body>
</html>
