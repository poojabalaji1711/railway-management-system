<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c"   uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<c:if test="${empty sessionScope.loggedUser || sessionScope.loggedUser.role != 'admin'}">
  <c:redirect url="/login.jsp"/>
</c:if>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reports – Admin – RailMS</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>

<nav class="navbar">
  <a class="navbar-brand" href="${pageContext.request.contextPath}/">Rail<span>MS</span></a>
  <ul class="nav-links">
    <li><a href="${pageContext.request.contextPath}/admin/dashboard.jsp">Dashboard</a></li>
    <li><a href="${pageContext.request.contextPath}/admin/trains">Trains</a></li>
    <li><a href="${pageContext.request.contextPath}/admin/reports?type=daily" class="active">Reports</a></li>
    <li><a href="${pageContext.request.contextPath}/logout">Logout</a></li>
  </ul>
</nav>

<div class="container" style="padding-top:2rem;">

  <div class="page-header">
    <h1 class="page-title">Reports</h1>
    <p class="page-sub">Analytics and booking statistics</p>
  </div>

  <!-- Summary stats -->
  <c:if test="${not empty stats}">
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-label">Total bookings</div>
        <div class="stat-value">${stats.totalBookings}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Total revenue</div>
        <div class="stat-value">₹<fmt:formatNumber value="${stats.totalRevenue}" type="number" minFractionDigits="2"/></div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Cancellations</div>
        <div class="stat-value">${stats.cancellations}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Registered users</div>
        <div class="stat-value">${stats.totalUsers}</div>
      </div>
    </div>
  </c:if>

  <!-- Report type tabs -->
  <div style="display:flex; gap:.5rem; margin-bottom:1.5rem; flex-wrap:wrap;">
    <a href="${pageContext.request.contextPath}/admin/reports?type=daily"
       class="btn ${reportType == 'daily' ? 'btn-primary' : 'btn-outline'}">Daily Bookings</a>
    <a href="${pageContext.request.contextPath}/admin/reports?type=revenue"
       class="btn ${reportType == 'revenue' ? 'btn-primary' : 'btn-outline'}">Revenue by Train</a>
    <a href="${pageContext.request.contextPath}/admin/reports?type=cancellation"
       class="btn ${reportType == 'cancellation' ? 'btn-primary' : 'btn-outline'}">Cancellations</a>
  </div>

  <!-- Daily bookings table -->
  <c:if test="${not empty dailyData}">
    <div class="card">
      <div class="card-header">Daily bookings – last 30 days</div>
      <div class="table-responsive">
        <table>
          <thead><tr><th>Date</th><th>Bookings</th><th>Revenue (₹)</th></tr></thead>
          <tbody>
            <c:forEach var="row" items="${dailyData}">
              <tr>
                <td>${row.day}</td>
                <td>${row.totalBookings}</td>
                <td>
                  <fmt:formatNumber value="${row.revenue}" type="number"
                                    minFractionDigits="2" maxFractionDigits="2"/>
                </td>
              </tr>
            </c:forEach>
          </tbody>
        </table>
      </div>
    </div>
  </c:if>

  <!-- Revenue by train -->
  <c:if test="${not empty revenueData}">
    <div class="card">
      <div class="card-header">Revenue by train</div>
      <div class="table-responsive">
        <table>
          <thead><tr><th>Train No.</th><th>Name</th><th>Bookings</th><th>Revenue (₹)</th></tr></thead>
          <tbody>
            <c:forEach var="row" items="${revenueData}">
              <tr>
                <td><span class="badge badge-info">${row.trainNumber}</span></td>
                <td>${row.trainName}</td>
                <td>${row.bookings}</td>
                <td><fmt:formatNumber value="${row.revenue}" type="number" minFractionDigits="2"/></td>
              </tr>
            </c:forEach>
          </tbody>
        </table>
      </div>
    </div>
  </c:if>

  <!-- Cancellations -->
  <c:if test="${not empty cancellations}">
    <div class="card">
      <div class="card-header">Cancellation report</div>
      <div class="table-responsive">
        <table>
          <thead>
            <tr><th>PNR</th><th>Passenger</th><th>Train</th><th>Travel date</th><th>Fare</th><th>Refund</th></tr>
          </thead>
          <tbody>
            <c:forEach var="row" items="${cancellations}">
              <tr>
                <td><strong>${row.pnr}</strong></td>
                <td>${row.userName}</td>
                <td>${row.trainName}</td>
                <td>${row.travelDate}</td>
                <td>₹<fmt:formatNumber value="${row.fare}" type="number" minFractionDigits="2"/></td>
                <td>
                  <c:choose>
                    <c:when test="${row.refundStatus == 'Refunded'}">
                      <span class="badge badge-success">Refunded</span>
                    </c:when>
                    <c:otherwise>
                      <span class="badge badge-warning">${row.refundStatus}</span>
                    </c:otherwise>
                  </c:choose>
                </td>
              </tr>
            </c:forEach>
          </tbody>
        </table>
      </div>
    </div>
  </c:if>

  <c:if test="${not empty error}">
    <div class="alert alert-danger">${error}</div>
  </c:if>

</div>
</body>
</html>
